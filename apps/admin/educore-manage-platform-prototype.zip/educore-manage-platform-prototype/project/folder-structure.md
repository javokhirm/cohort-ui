# Folder Structure — EduCore Platform (Confirmed)

## Design Principles

1. **Domain-first, not layer-first.** Group by business capability, not technical role.
2. **API surfaces are thin.** The four platform APIs compose domain services; zero
   business logic in controllers.
3. **Strict dependency direction.** `api → domain → infra → common`. Never backwards.
4. **Domains are encapsulated.** Each domain exposes a public contract (a barrel of
   services); other domains may not reach into its internals.
5. **One file, one responsibility.** Split fat services by operation.
6. **Workers co-locate with their domain** but bootstrap from a separate process entry.

---

## The Structure

```
src/
│
├── main.ts                                 # HTTP entrypoint (API process)
├── worker.ts                               # BullMQ entrypoint (worker process)
├── app.module.ts                           # Root module for the API process
├── worker.module.ts                        # Root module for the worker process
│
│
│   ╔═════════════════════════════════════════════════════════════════════╗
│   ║  API LAYER — thin controllers + DTOs + mappers, grouped by surface   ║
│   ║  Imports domain services. No business logic, no DB access.           ║
│   ╚═════════════════════════════════════════════════════════════════════╝
│
├── api/
│   │
│   ├── admin/                              # /api/v1/admin/*  — Super Admin Panel
│   │   ├── admin-api.module.ts
│   │   ├── admin-api.guard.ts              # PlatformAdminGuard (BYPASSRLS role)
│   │   ├── controllers/
│   │   │   ├── tenants.controller.ts
│   │   │   ├── subscriptions.controller.ts
│   │   │   ├── subscription-tiers.controller.ts
│   │   │   ├── platform-audit.controller.ts
│   │   │   └── platform-dashboard.controller.ts
│   │   ├── mappers/
│   │   │   └── tenant.mapper.ts
│   │   └── dto/
│   │       ├── create-tenant.dto.ts
│   │       ├── update-tenant.dto.ts
│   │       └── tenant-response.dto.ts
│   │
│   ├── manage/                             # /api/v1/manage/*  — Staff Web App
│   │   ├── manage-api.module.ts
│   │   ├── manage-api.guard.ts             # @Roles('OWNER','ADMIN','MANAGER')
│   │   ├── controllers/                    # one per resource (see API design doc)
│   │   │   ├── students.controller.ts
│   │   │   ├── staff.controller.ts
│   │   │   ├── groups.controller.ts
│   │   │   ├── sessions.controller.ts
│   │   │   ├── invoices.controller.ts
│   │   │   ├── payments.controller.ts
│   │   │   ├── payrolls.controller.ts
│   │   │   ├── leads.controller.ts
│   │   │   ├── ... (≈26 controllers)
│   │   │   └── dashboard.controller.ts
│   │   ├── mappers/                        # entity → manage DTO (full fidelity)
│   │   │   ├── student.mapper.ts
│   │   │   ├── invoice.mapper.ts
│   │   │   └── ...
│   │   └── dto/                            # nested per resource
│   │       ├── students/
│   │       │   ├── create-student.dto.ts
│   │       │   ├── update-student.dto.ts
│   │       │   ├── student-list-query.dto.ts
│   │       │   └── student-response.dto.ts
│   │       ├── invoices/
│   │       └── ...
│   │
│   ├── teach/                              # /api/v1/teach/*  — Teacher App
│   │   ├── teach-api.module.ts
│   │   ├── teach-api.guard.ts              # @Roles('TEACHER')
│   │   ├── controllers/
│   │   │   ├── my-sessions.controller.ts
│   │   │   ├── my-groups.controller.ts
│   │   │   ├── attendance.controller.ts
│   │   │   ├── assessments.controller.ts
│   │   │   ├── materials.controller.ts
│   │   │   └── student-profiles.controller.ts
│   │   ├── mappers/                        # entity → teacher DTO (limited fields)
│   │   │   └── teacher-student.mapper.ts
│   │   └── dto/
│   │       ├── batch-attendance.dto.ts
│   │       ├── batch-results.dto.ts
│   │       └── ...
│   │
│   ├── portal/                             # /api/v1/portal/*  — Student & Parent
│   │   ├── portal-api.module.ts
│   │   ├── portal-api.guard.ts             # @Roles('STUDENT','PARENT')
│   │   ├── controllers/
│   │   │   ├── profile.controller.ts
│   │   │   ├── children.controller.ts
│   │   │   ├── schedule.controller.ts
│   │   │   ├── results.controller.ts
│   │   │   ├── report-cards.controller.ts
│   │   │   ├── invoices.controller.ts
│   │   │   ├── payments.controller.ts
│   │   │   └── notifications.controller.ts
│   │   ├── mappers/                        # entity → portal DTO (own data only)
│   │   │   └── ...
│   │   └── dto/
│   │       └── ...
│   │
│   └── public/                             # /api/v1/public/*  — Unauthenticated
│       ├── public-api.module.ts
│       ├── controllers/
│       │   ├── auth.controller.ts
│       │   ├── webhooks.controller.ts      # Click/Payme/Uzum callbacks
│       │   └── health.controller.ts
│       └── dto/
│           ├── login.dto.ts
│           └── reset-password.dto.ts
│
│
│   ╔═════════════════════════════════════════════════════════════════════╗
│   ║  DOMAIN LAYER — business logic, by bounded context.                  ║
│   ║  Each domain: index.ts (public contract) + entities + repositories   ║
│   ║  + services + events + listeners + (optional) workers.               ║
│   ╚═════════════════════════════════════════════════════════════════════╝
│
├── domain/
│   │
│   ├── platform/                           # Tenants, branches, subscriptions, audit
│   │   ├── index.ts                        # ← public contract (exports services + types)
│   │   ├── platform.module.ts
│   │   ├── entities/
│   │   │   ├── tenant.entity.ts
│   │   │   ├── branch.entity.ts
│   │   │   ├── subscription.entity.ts
│   │   │   ├── subscription-tier.entity.ts
│   │   │   ├── tenant-settings.entity.ts
│   │   │   └── audit-log.entity.ts
│   │   ├── repositories/
│   │   │   ├── tenant.repository.ts
│   │   │   └── audit-log.repository.ts
│   │   ├── services/
│   │   │   ├── tenant.service.ts
│   │   │   ├── branch.service.ts
│   │   │   ├── subscription.service.ts
│   │   │   └── audit-log.service.ts
│   │   ├── events/
│   │   │   ├── tenant-created.event.ts
│   │   │   └── tenant-suspended.event.ts
│   │   └── constants/
│   │       └── tenant-status.enum.ts
│   │
│   ├── identity/                           # Auth, users, memberships, RBAC, TENANT CONTEXT
│   │   ├── index.ts
│   │   ├── identity.module.ts
│   │   ├── entities/
│   │   │   ├── user.entity.ts
│   │   │   ├── tenant-user.entity.ts
│   │   │   ├── role.entity.ts
│   │   │   ├── permission.entity.ts
│   │   │   ├── role-permission.entity.ts
│   │   │   └── user-role-assignment.entity.ts
│   │   ├── repositories/
│   │   │   ├── user.repository.ts
│   │   │   └── role.repository.ts
│   │   ├── services/
│   │   │   ├── auth.service.ts             # login, refresh, password reset
│   │   │   ├── user.service.ts
│   │   │   ├── membership.service.ts
│   │   │   ├── role.service.ts
│   │   │   ├── role-assignment.service.ts
│   │   │   ├── permission-resolver.service.ts
│   │   │   └── tenant-resolver.service.ts  # subdomain/JWT → tenant (uses platform repo)
│   │   ├── strategies/
│   │   │   ├── jwt.strategy.ts
│   │   │   └── jwt-refresh.strategy.ts
│   │   ├── guards/
│   │   │   ├── jwt-auth.guard.ts
│   │   │   ├── tenant-context.guard.ts     # ← sets tenant ALS context (the fix; see below)
│   │   │   ├── tenant-role.guard.ts        # @Roles(...)
│   │   │   └── rbac.guard.ts               # @Permissions(...)
│   │   ├── decorators/
│   │   │   ├── current-user.decorator.ts
│   │   │   ├── roles.decorator.ts
│   │   │   └── permissions.decorator.ts
│   │   └── constants/
│   │       ├── system-roles.enum.ts
│   │       └── permissions.enum.ts
│   │
│   ├── people/                             # Students, staff, guardians
│   │   ├── index.ts
│   │   ├── people.module.ts
│   │   ├── entities/ { student, staff, student-guardian }
│   │   ├── repositories/ { student, staff }
│   │   ├── services/
│   │   │   ├── student.service.ts
│   │   │   ├── student-code.generator.ts
│   │   │   ├── staff.service.ts
│   │   │   ├── staff-code.generator.ts
│   │   │   └── guardian.service.ts
│   │   └── events/ { student-registered, student-graduated }
│   │
│   ├── crm/                                # Leads & pipeline
│   │   ├── index.ts
│   │   ├── crm.module.ts
│   │   ├── entities/ { lead, lead-activity }
│   │   ├── repositories/ { lead }
│   │   ├── services/
│   │   │   ├── lead.service.ts
│   │   │   ├── lead-activity.service.ts
│   │   │   └── lead-conversion.service.ts  # → people + academics
│   │   └── events/ { lead-converted }
│   │
│   ├── academics/                          # Courses, rooms, groups, sessions, enrollments
│   │   ├── index.ts
│   │   ├── academics.module.ts
│   │   ├── entities/ { course, room, group, session, enrollment, learning-material }
│   │   ├── repositories/ { group, session, enrollment }
│   │   ├── services/
│   │   │   ├── course.service.ts
│   │   │   ├── room.service.ts
│   │   │   ├── group.service.ts
│   │   │   ├── session.service.ts
│   │   │   ├── session-generator.service.ts    # schedule_rule → sessions
│   │   │   ├── enrollment.service.ts
│   │   │   ├── conflict-detector.service.ts
│   │   │   └── learning-material.service.ts
│   │   ├── workers/
│   │   │   └── session-generation.processor.ts
│   │   └── events/ { session-cancelled, enrollment-created }
│   │
│   ├── assessment/                         # Attendance, grading, exams, report cards
│   │   ├── index.ts
│   │   ├── assessment.module.ts
│   │   ├── entities/ { attendance, grading-scale, assessment, assessment-result,
│   │   │               report-card, report-card-line }
│   │   ├── repositories/ { attendance, assessment, report-card }
│   │   ├── services/
│   │   │   ├── attendance.service.ts
│   │   │   ├── grading-scale.service.ts
│   │   │   ├── assessment.service.ts
│   │   │   ├── assessment-result.service.ts
│   │   │   ├── grade-calculator.service.ts
│   │   │   ├── report-card.service.ts
│   │   │   └── report-card-renderer.service.ts
│   │   ├── workers/
│   │   │   └── report-card-generation.processor.ts
│   │   └── events/ { attendance-marked, results-published }
│   │
│   ├── billing/                            # AR: fee plans, invoices, payments, discounts
│   │   ├── index.ts
│   │   ├── billing.module.ts
│   │   ├── entities/ { fee-plan, invoice, invoice-line-item, payment,
│   │   │               discount, invoice-discount }
│   │   ├── repositories/ { invoice, payment }
│   │   ├── services/
│   │   │   ├── fee-plan.service.ts
│   │   │   ├── invoice.service.ts
│   │   │   ├── invoice-generation.service.ts
│   │   │   ├── invoice-calculator.service.ts
│   │   │   ├── payment.service.ts
│   │   │   ├── payment-reconciliation.service.ts   # webhook → invoice status
│   │   │   ├── discount.service.ts
│   │   │   └── overdue-detector.service.ts
│   │   ├── workers/
│   │   │   ├── invoice-generation.processor.ts
│   │   │   └── overdue-check.processor.ts
│   │   └── events/ { invoice-created, payment-received, invoice-overdue }
│   │
│   ├── finance/                            # AP: expenses, payroll
│   │   ├── index.ts
│   │   ├── finance.module.ts
│   │   ├── entities/ { expense, teacher-payroll }
│   │   ├── repositories/ { expense, payroll }
│   │   ├── services/
│   │   │   ├── expense.service.ts
│   │   │   ├── payroll.service.ts
│   │   │   └── payroll-calculator.service.ts
│   │   ├── workers/
│   │   │   └── payroll-generation.processor.ts
│   │   └── events/ { payroll-approved }
│   │
│   ├── communication/                      # Templates, dispatch, reminders
│   │   ├── index.ts
│   │   ├── communication.module.ts
│   │   ├── entities/ { notification-template, notification, payment-reminder-rule }
│   │   ├── repositories/ { notification-template, notification }
│   │   ├── services/
│   │   │   ├── notification-template.service.ts
│   │   │   ├── notification.service.ts          # enqueue to outbox
│   │   │   ├── template-renderer.service.ts
│   │   │   ├── reminder-rule.service.ts
│   │   │   └── reminder-scheduler.service.ts
│   │   ├── listeners/                            # ← NEW: reacts to other domains' events
│   │   │   ├── absence-alert.listener.ts        # on AttendanceMarkedEvent (ABSENT)
│   │   │   ├── results-published.listener.ts    # on ResultsPublishedEvent
│   │   │   ├── payment-received.listener.ts     # on PaymentReceivedEvent (receipt)
│   │   │   └── invoice-overdue.listener.ts      # on InvoiceOverdueEvent
│   │   ├── workers/
│   │   │   ├── notification-dispatch.processor.ts
│   │   │   └── reminder-check.processor.ts
│   │   └── events/ { notification-failed }
│   │
│   └── analytics/                          # ← NEW: cross-domain read-models & dashboards
│       ├── index.ts
│       ├── analytics.module.ts             # read-only; depends on many domains
│       ├── services/
│       │   ├── financial-dashboard.service.ts   # revenue, outstanding, P&L, ROI
│       │   ├── academic-dashboard.service.ts    # pass rates, score distributions
│       │   ├── attendance-dashboard.service.ts  # attendance rates
│       │   └── crm-dashboard.service.ts         # funnel conversion
│       └── dto/                            # internal read-model shapes (not API DTOs)
│           └── ...
│
│
│   ╔═════════════════════════════════════════════════════════════════════╗
│   ║  INFRA — cross-cutting mechanism. Imports only `common`.             ║
│   ╚═════════════════════════════════════════════════════════════════════╝
│
├── infra/
│   │
│   ├── database/
│   │   ├── database.module.ts
│   │   ├── data-source.ts                  # TypeORM CLI data source (migrations)
│   │   ├── migrations/
│   │   │   ├── 1700000000000-InitialSchema.ts
│   │   │   ├── 1700000000001-EnableRLS.ts
│   │   │   └── 1700000000002-SeedSystemRoles.ts
│   │   └── seeders/ { roles, permissions }
│   │
│   ├── tenant/                             # PURE mechanism — no DB, no domain imports
│   │   ├── tenant.module.ts
│   │   ├── tenant-context.ts               # AsyncLocalStorage store + getters
│   │   ├── tenant.subscriber.ts            # auto-stamps tenant_id on insert
│   │   └── tenant-transaction.runner.ts    # SET LOCAL app.current_tenant
│   │
│   ├── cache/ { cache.module.ts, cache-keys.ts }            # Redis
│   ├── queue/ { queue.module.ts, queue-names.ts, base.processor.ts }  # BullMQ
│   ├── storage/ { storage.module.ts, storage.service.ts }   # S3
│   │
│   └── integrations/                       # External adapters (interface + impls)
│       ├── integrations.module.ts
│       ├── sms/ { sms.interface.ts, eskiz.adapter.ts, play-mobile.adapter.ts }
│       ├── telegram/ { telegram.service.ts, telegram-bot.update.ts }
│       └── payments/
│           ├── payment-gateway.interface.ts
│           ├── click.adapter.ts
│           ├── payme.adapter.ts
│           ├── uzum.adapter.ts
│           └── webhook-verifier.service.ts
│
│
│   ╔═════════════════════════════════════════════════════════════════════╗
│   ║  COMMON — zero business logic, zero project imports.                 ║
│   ╚═════════════════════════════════════════════════════════════════════╝
│
├── common/
│   ├── base/ { base.entity.ts, base.repository.ts, base-crud.service.ts }
│   ├── dto/ { pagination.dto.ts, sort.dto.ts, api-response.dto.ts }
│   ├── filters/ { global-exception.filter.ts }
│   ├── interceptors/ { response-transform, logging, timeout }
│   ├── pipes/ { id-validation.pipe.ts }
│   ├── transformers/ { numeric.transformer.ts }
│   ├── utils/ { date.util.ts, money.util.ts, code-generator.util.ts }
│   └── types/ { index.ts }
│
│
└── config/
    ├── config.module.ts
    ├── app.config.ts
    ├── database.config.ts
    ├── redis.config.ts
    ├── jwt.config.ts
    ├── storage.config.ts
    ├── sms.config.ts
    ├── telegram.config.ts
    └── payment-gateways.config.ts


test/                                       # mirrors src/ (unit | integration | e2e)
├── unit/domain/{billing,assessment,academics,...}/*.spec.ts
├── integration/{setup,billing,academics}/*.spec.ts
└── e2e/{admin,manage,teach,portal,public}/*.e2e-spec.ts
```

---

## Naming Conventions

| Suffix            | Meaning                                          | Lives in                                      |
| ----------------- | ------------------------------------------------ | --------------------------------------------- |
| `*.controller.ts` | HTTP route handler (thin)                        | `api/<surface>/controllers/`                  |
| `*.mapper.ts`     | Entity → DTO conversion for a surface            | `api/<surface>/mappers/`                      |
| `*.dto.ts`        | Request/response shape (class-validator)         | `api/<surface>/dto/`                          |
| `*.service.ts`    | Business logic                                   | `domain/<ctx>/services/`                      |
| `*.repository.ts` | Custom queries (only when beyond TypeORM basics) | `domain/<ctx>/repositories/`                  |
| `*.entity.ts`     | TypeORM entity                                   | `domain/<ctx>/entities/`                      |
| `*.event.ts`      | Domain event (payload class)                     | `domain/<ctx>/events/`                        |
| `*.listener.ts`   | Reacts to another domain's event                 | `domain/<ctx>/listeners/`                     |
| `*.processor.ts`  | BullMQ job consumer                              | `domain/<ctx>/workers/`                       |
| `*.guard.ts`      | Auth/RBAC gate                                   | `domain/identity/guards/` or `api/<surface>/` |
| `*.adapter.ts`    | External provider implementation                 | `infra/integrations/<provider>/`              |
| `*.generator.ts`  | Code/sequence generation (STU-2024-001)          | `domain/<ctx>/services/`                      |

---

## Module Encapsulation (the `index.ts` rule)

Every domain exposes a **public contract** via its barrel and nothing else:

```typescript
// domain/people/index.ts  — the ONLY thing other domains may import
export { PeopleModule } from './people.module';
export { StudentService } from './services/student.service';
export { StaffService } from './services/staff.service';
export { Student } from './entities/student.entity'; // entity exported as a read type
export { StudentRegisteredEvent } from './events/student-registered.event';
// repositories, generators, internal services are NOT exported
```

```typescript
// ✅ allowed
import { StudentService } from 'domain/people';
// ❌ forbidden — reaching past the contract into internals
import { StudentRepository } from 'domain/people/repositories/student.repository';
```

---

## Dependency Rules

```
   api/  ──▶  domain/  ──▶  infra/  ──▶  common/
                  │                          ▲
                  └──────────────────────────┘   (domain may use common directly)

  ✅ api → domain        ✅ domain → domain (via index.ts only)
  ✅ api → common        ✅ domain → infra
  ✅ domain → common     ✅ infra → common
  ❌ api → infra         ❌ domain → api
  ❌ infra → domain      ❌ infra → api        ❌ common → anything
```

### Domain cross-dependencies (allowed, kept minimal)

```
  analytics      → billing, finance, academics, assessment, crm   (read-only)
  communication  → (via events only — listens, imports nothing)
  billing        → people, academics
  finance        → people, academics
  assessment     → academics, people
  crm            → people, academics
  identity       → platform                 (tenant resolution)
```

`communication` is fully event-driven: it imports no other domain. Other domains emit
events; `communication/listeners/*` react. This keeps the most "spidery" domain
decoupled.

---

## Tenant Context & Auth Sequencing

Per request:

```
1. JwtAuthGuard            (identity)  → verifies token, attaches principal
2. TenantContextGuard      (identity)  → resolves tenant (subdomain ⨉ JWT, cross-checked),
                                          calls infra ALS store via enterWith() to open
                                          context { tenantId, userId, branchScope, roles }
3. TenantRoleGuard / RbacGuard (identity) → authorizes
4. Controller → Domain Service
5. TenantTransactionRunner (infra)     → SET LOCAL app.current_tenant inside each tx
                                          → PostgreSQL RLS enforces isolation
```

- `infra/tenant/` stays a **pure mechanism**: the ALS store, the insert subscriber, and
  the transaction runner. It imports only `common`. ✅
- The **resolution** (which needs the tenant repository) lives in
  `domain/identity/services/tenant-resolver.service.ts` + `tenant-context.guard.ts`,
  which legitimately depend on `domain/platform` and use the `infra/tenant` store. ✅
- Guards run **after** the JWT is verified (unlike middleware), so the JWT tenant claim
  is trustworthy at resolution time.

Public routes (`/api/v1/public/*`) skip guards 1–3; a lightweight subdomain check sets a
provisional tenant for tenant-scoped login.

---

## Process Entrypoints

One codebase, two deployables:

```typescript
// main.ts — API process (HTTP)
const app = await NestFactory.create(AppModule);
app.setGlobalPrefix('api/v1');
await app.listen(process.env.PORT);

// worker.ts — worker process (no HTTP server)
const app = await NestFactory.createApplicationContext(WorkerModule);
// WorkerModule imports the domain modules whose workers/*.processor.ts register
// BullMQ consumers; the same DI graph, no controllers.
```

`app.module.ts` imports the `api/*` modules + all domain + infra.
`worker.module.ts` imports the domain modules (for their processors) + infra, but **not**
the `api/*` modules. Both share `domain/` and `infra/` unchanged.

---

## Evolution Path (when scale demands it)

The structure is built so each step below is a clean cut, not a rewrite:

1. **Nx / Turborepo monorepo.** Promote `domain/*` and `infra/*` into `libs/`, and
   `api/*` + entrypoints into `apps/`. The `index.ts` contracts become the lib public
   APIs — no import changes needed.
2. **Independent service extraction.** A hot surface (e.g. `portal`) becomes its own
   `apps/portal-api` importing the same domain libs. Because controllers never hold
   logic, you move only the thin API module.
3. **CQRS for the heaviest domains.** `billing` and `assessment` can adopt
   `@nestjs/cqrs` (commands/queries/handlers) internally without affecting their public
   `index.ts` contract or any caller.
4. **Per-tenant DB extraction.** A large enterprise tenant moves to its own database;
   the `infra/tenant` connection resolution changes, nothing in `domain/` does.
