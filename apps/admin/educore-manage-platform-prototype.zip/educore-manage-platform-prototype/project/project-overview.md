# EduCore — Project Overview

## Table of Contents

- [1. Introduction](#1-introduction)
- [2. System Architecture](#2-system-architecture)
- [3. Tech Stack](#3-tech-stack)
- [4. Multi-Tenancy & Data Isolation](#4-multi-tenancy--data-isolation)
- [5. Platform Surfaces](#5-platform-surfaces)
  - [5.1. Super Admin Panel](#51-super-admin-panel-internal)
  - [5.2. Staff Web App (Owner / Admin / Manager)](#52-staff-web-app-owner--admin--manager)
  - [5.3. Teacher App](#53-teacher-app-web--mobile-pwa)
  - [5.4. Student & Parent Portal](#54-student--parent-portal-telegram-bot--mobile-pwa)
- [6. Core Modules & Features](#6-core-modules--features)
  - [6.1. Identity & Access Management](#61-identity--access-management)
  - [6.2. Student & Personnel Management](#62-student--personnel-management)
  - [6.3. CRM & Lead Pipeline](#63-crm--lead-pipeline)
  - [6.4. Academics & Scheduling](#64-academics--scheduling)
  - [6.5. Assessment & Progress Tracking](#65-assessment--progress-tracking)
  - [6.6. Financial & Billing Management](#66-financial--billing-management)
  - [6.7. Communication & Notifications](#67-communication--notifications)
  - [6.8. Reporting & Dashboards](#68-reporting--dashboards)
- [7. Data Model Summary](#7-data-model-summary)
- [8. Key Design Decisions](#8-key-design-decisions)
- [9. Repository Structure](#9-repository-structure)
- [10. Roadmap & Phasing](#10-roadmap--phasing)

---

## 1. Introduction

EduCore is a **multi-tenant B2B SaaS platform** for managing education centers. A single education-center business (the _tenant_) signs up once and can manage one or many physical _branches_ from a unified back office. The platform handles the full operational lifecycle: acquiring leads, enrolling students, scheduling and delivering classes, tracking attendance and grades, billing families, paying teachers, and communicating with parents — all with strict data isolation so one center's data is never reachable from another's.

**Target market:** Private education centers, tutoring academies, language schools, and test-prep institutes — initially in Uzbekistan (UZS, Click/Payme/Uzum payments, Telegram-first communication, uz/ru/en locale support).

**Core promise:** One platform replaces the spreadsheets, Telegram groups, and disconnected tools an education center stitches together today, giving the owner a real-time view of academic quality, operational health, and financial performance across every branch.

---

## 2. System Architecture

The system is a **modular monolith** (one deployable, internally split into domain modules that can become separate services later) with tenant-aware background workers for heavy/scheduled operations.

```
┌──────────────────────────────────────────────────────────────────────┐
│                          CLIENT SURFACES                             │
│                                                                      │
│  ┌──────────────┐  ┌──────────────┐  ┌───────────┐  ┌────────────┐  │
│  │ Super Admin  │  │  Staff Web   │  │ Teacher   │  │ Student /  │  │
│  │   Panel      │  │    App       │  │   App     │  │ Parent Bot │  │
│  └──────┬───────┘  └──────┬───────┘  └─────┬─────┘  └─────┬──────┘  │
└─────────┼─────────────────┼────────────────┼───────────────┼─────────┘
          │                 │                │               │
          ▼                 ▼                ▼               ▼
┌──────────────────────────────────────────────────────────────────────┐
│                      NestJS API (stateless, N pods)                   │
│                                                                      │
│  Auth Guard ─▶ Tenant Middleware ─▶ RBAC Guard ─▶ Controller/Service │
│                      │                                               │
│       AsyncLocalStorage { tenantId, userId, branchScope, roles }     │
└──────────────────┬───────────────────────┬───────────────────────────┘
                   │                       │
      ┌────────────▼────────────┐   ┌──────▼──────────────┐
      │  PostgreSQL 14+         │   │  Redis               │
      │  ┌───────────────────┐  │   │  • Session / cache   │
      │  │ Row-Level Security│  │   │  • BullMQ job queues │
      │  │ (tenant isolation)│  │   └──────┬──────────────┘
      │  └───────────────────┘  │          │
      │  Primary + Read Replica │   ┌──────▼──────────────┐
      └─────────────────────────┘   │  Background Workers  │
                                    │  • Invoice generator │
                                    │  • Payment reminders │
                                    │  • Payroll runs      │
                                    │  • Notification      │
                                    │    dispatch (SMS /   │
                                    │    Telegram / Email) │
                                    │  • Webhook processor │
                                    └──────┬──────────────┘
                                           │
                      ┌────────────────────┼────────────────────┐
                      ▼                    ▼                    ▼
               SMS Gateway         Telegram Bot API    Payment Gateways
             (Eskiz / Play Mobile)                   (Click / Payme / Uzum)
```

Every request goes through: **Authentication → Tenant resolution → RBAC check → Business logic → Database (filtered by RLS)**. Background workers carry the `tenantId` in the job payload and set the same RLS context before touching data.

---

## 3. Tech Stack

| Layer           | Technology                                                        |
| --------------- | ----------------------------------------------------------------- |
| Backend API     | NestJS (TypeScript), modular monolith                             |
| ORM             | TypeORM                                                           |
| Database        | PostgreSQL 14+ with Row-Level Security                            |
| Cache & Queues  | Redis + BullMQ                                                    |
| Authentication  | JWT access + refresh tokens, Argon2 password hashing              |
| SMS             | Eskiz / Play Mobile API                                           |
| Messaging       | Telegram Bot API                                                  |
| Payments        | Click, Payme, Uzum gateway integrations                           |
| File Storage    | S3-compatible object store (for materials, receipts, report PDFs) |
| Monitoring      | Structured JSON logs with `tenantId`, Prometheus metrics, tracing |
| Region defaults | UZS currency · `Asia/Tashkent` timezone · uz / ru / en locales    |

---

## 4. Multi-Tenancy & Data Isolation

**Model:** Shared database, shared schema, row-level isolation via `tenant_id`.

Every tenant-scoped table carries a `tenant_id` column. Isolation is enforced by **two independent layers** so a cross-tenant leak requires both to fail simultaneously:

**Layer 1 — Application:**

- `TenantMiddleware` resolves the active tenant from the subdomain + JWT claim (cross-checked) and writes it into per-request `AsyncLocalStorage`.
- A TypeORM `TenantSubscriber` auto-stamps `tenant_id` on every insert.
- Repositories scope queries to the current tenant by default.

**Layer 2 — Database (the guarantee):**

- Every tenant-scoped table has `ENABLE ROW LEVEL SECURITY` + `FORCE ROW LEVEL SECURITY`.
- Each request transaction runs `SET LOCAL app.current_tenant = '<tenantId>'`.
- The RLS policy `tenant_id = current_setting('app.current_tenant')::integer` constrains every query. An unset GUC yields NULL, matching zero rows (deny-by-default).

**Data hierarchy:**

```
Tenant (Education Center business)
  └─ Branch (physical campus / location)
       └─ Rooms, Courses, Groups, Sessions, Students, Staff, Invoices, ...
```

Branch-level access within a tenant is enforced at the application layer via
`branchScope` on user role assignments.

---

## 5. Platform Surfaces

The system exposes **one backend API** consumed by **four client surfaces**, each tailored to its audience.

### 5.1. Super Admin Panel (internal)

**Audience:** Platform operators (your team).

**Purpose:** Manage the multi-tenant ecosystem, onboard centers, monitor health.

| Feature                    | Description                                                                            | Primary tables                                        |
| -------------------------- | -------------------------------------------------------------------------------------- | ----------------------------------------------------- |
| Tenant management          | Create, activate, suspend, cancel education centers                                    | `tenants`, `branches`                                 |
| Subscription & billing     | Assign tiers, manage pricing, track subscription lifecycle                             | `subscription_tiers`, `subscriptions`                 |
| Feature flags              | Toggle features per tier (referral program, mock exams, max branches) via JSONB config | `subscription_tiers.features`                         |
| Tenant settings            | View/edit per-tenant configuration (branding, locale, integrations)                    | `tenant_settings`                                     |
| Platform audit trail       | Search all actions across tenants — who did what, when, with before/after snapshots    | `audit_logs`                                          |
| User directory             | Browse global identities, resolve cross-tenant memberships                             | `users`, `tenant_users`                               |
| System roles & permissions | Manage the default role/permission templates shipped to every new tenant               | `roles`, `permissions`, `role_permissions`            |
| Platform health dashboard  | Tenant count, MRR, churn, active users, error rates                                    | Aggregates across `tenants`, `subscriptions`, `users` |

### 5.2. Staff Web App (Owner / Admin / Manager)

**Audience:** Education center owners, branch administrators, operations managers.

**Purpose:** Full back-office for running a center — CRM, academics, finance, HR.

#### 5.2.1. CRM & Lead Pipeline

| Feature             | Description                                                                    | Primary tables                            |
| ------------------- | ------------------------------------------------------------------------------ | ----------------------------------------- |
| Lead capture        | Add new prospects manually or from Instagram/Telegram/website/walk-in/referral | `leads`                                   |
| Lead pipeline board | Kanban view: NEW → CONTACTED → TRIAL_BOOKED → ENROLLED / LOST                  | `leads.status`                            |
| Lead activity log   | Record calls, messages, trial visits, notes with timestamps                    | `lead_activities`                         |
| Lead assignment     | Assign leads to specific staff members for follow-up                           | `leads.assigned_to_staff_id`              |
| Lead conversion     | One-click convert a lead into an enrolled student                              | `leads.converted_student_id` → `students` |

#### 5.2.2. Student Management

| Feature                  | Description                                                                            | Primary tables                           |
| ------------------------ | -------------------------------------------------------------------------------------- | ---------------------------------------- |
| Student registration     | Create student profile with auto-generated code (STU-2024-001), link to user identity  | `students`, `users`                      |
| Student profiles         | Date of birth, gender, address, emergency contact, enrollment date, status             | `students`                               |
| Guardian management      | Link parents/guardians to students with relation type, primary flag, pickup permission | `student_guardians`, `users`             |
| Student status lifecycle | Active → Inactive / Graduated / Suspended with soft-delete recovery                    | `students.status`, `students.deleted_at` |
| Student search & filters | Filter by branch, status, group, enrollment date, course                               | `students` + joins                       |
| Bulk operations          | Batch status updates, group transfers                                                  | `students`, `enrollments`                |

#### 5.2.3. Staff & HR Management

| Feature            | Description                                                                                    | Primary tables          |
| ------------------ | ---------------------------------------------------------------------------------------------- | ----------------------- |
| Staff registration | Create staff/teacher profiles with auto-generated code, link to user identity                  | `staff`, `users`        |
| Staff profiles     | Department, specialization (array of subjects/skills), hire date, employment type, base salary | `staff`                 |
| Employment types   | Full-time, part-time, contractor — affects payroll calculations                                | `staff.employment_type` |
| Staff directory    | Search by branch, department, specialization, status                                           | `staff`                 |

#### 5.2.4. Role & Access Control

| Feature                   | Description                                                                                     | Primary tables                                   |
| ------------------------- | ----------------------------------------------------------------------------------------------- | ------------------------------------------------ |
| Role management           | Create custom roles per tenant (beyond system defaults: OWNER, ADMIN, TEACHER, STUDENT, PARENT) | `roles`                                          |
| Granular permissions      | Assign fine-grained permissions to roles (student.create, invoice.void, attendance.mark, etc.)  | `permissions`, `role_permissions`                |
| Branch-scoped assignments | Assign roles per branch — "ADMIN at Yunusobod, TEACHER at Chilonzor" for the same user          | `user_role_assignments`                          |
| Multi-role users          | A single user can hold multiple roles within a tenant                                           | `user_role_assignments` (multiple rows per user) |

#### 5.2.5. Course & Schedule Management

| Feature                  | Description                                                                                    | Primary tables                                               |
| ------------------------ | ---------------------------------------------------------------------------------------------- | ------------------------------------------------------------ |
| Course catalog           | Create and manage courses (IELTS Prep, Math Grade 5) with level and default duration           | `courses`                                                    |
| Group/cohort management  | Create class groups under a course with assigned teacher, room, capacity, date range           | `groups`                                                     |
| Recurring schedule rules | Define weekly patterns (MON/WED/FRI 09:00–10:30) that auto-generate individual sessions        | `groups.schedule_rule` → `sessions`                          |
| Session calendar         | Visual calendar of all sessions per branch with date, time, room, teacher, topic, status       | `sessions`                                                   |
| Session overrides        | Reschedule, cancel (with reason), or assign a substitute teacher/room for individual sessions  | `sessions.status`, `sessions.teacher_id`, `sessions.room_id` |
| Room management          | Define rooms per branch with capacity and type (classroom, lab, online)                        | `rooms`                                                      |
| Conflict detection       | Prevent double-booking of rooms and teachers at the service layer                              | `sessions` (room_id + teacher_id + session_date + time)      |
| Enrollment roster        | Enroll students into groups, view roster, manage status (active/dropped/completed/transferred) | `enrollments`                                                |

#### 5.2.6. Attendance Monitoring (admin view)

| Feature             | Description                                                         | Primary tables                                            |
| ------------------- | ------------------------------------------------------------------- | --------------------------------------------------------- |
| Attendance overview | View attendance rates per group, branch, student across date ranges | `attendances` aggregates                                  |
| Absence alerts      | Identify students with chronic absences for follow-up               | `attendances.status`                                      |
| Attendance audit    | View who marked attendance and when (accountability)                | `attendances.marked_by_staff_id`, `attendances.marked_at` |

#### 5.2.7. Assessment & Progress (admin view)

| Feature             | Description                                                                         | Primary tables                  |
| ------------------- | ----------------------------------------------------------------------------------- | ------------------------------- |
| Grading scale setup | Create custom grading scales: numeric, percentage, letter (A/B/C), band (IELTS 0–9) | `grading_scales`                |
| Assessment overview | View all exams/quizzes across groups, dates, published status                       | `assessments`                   |
| Result analytics    | Score distributions, pass rates, group/branch comparisons                           | `assessment_results` aggregates |

#### 5.2.8. Financial Management

| Feature                  | Description                                                                                                                                           | Primary tables                                                           |
| ------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------ |
| Fee plan setup           | Create billing templates per branch/course: amount, currency, billing cycle (monthly/quarterly/one-time/per-session), due day, late fee, grace period | `fee_plans`                                                              |
| Invoice generation       | Automated or manual invoice creation with line items, linked to enrollment and fee plan                                                               | `invoices`, `invoice_line_items`                                         |
| Invoice lifecycle        | Draft → Unpaid → Partial → Paid / Overdue → Void / Refunded                                                                                           | `invoices.status`                                                        |
| Discount management      | Create percentage or fixed-amount discounts with promo codes, usage caps, validity windows                                                            | `discounts`                                                              |
| Apply discounts          | Attach discounts to specific invoices, track applied amount                                                                                           | `invoice_discounts`                                                      |
| Payment tracking         | Record cash payments; receive Click/Payme/Uzum webhook confirmations with provider txn IDs                                                            | `payments`                                                               |
| Idempotent webhooks      | Deduplicate retried gateway callbacks via unique `idempotency_key`                                                                                    | `payments.idempotency_key`                                               |
| Payment methods          | Cash, Click, Payme, Uzum, card, bank transfer                                                                                                         | `payments.method`                                                        |
| Outstanding balance view | Per-student balance: invoiced vs paid, overdue invoices                                                                                               | `invoices.total`, `invoices.amount_paid`                                 |
| Expense tracking         | Record operating expenses (rent, utilities, marketing, salary) by branch with receipts                                                                | `expenses`                                                               |
| Payroll management       | Generate teacher payroll: period, gross/deductions/net, breakdown (hours taught, rate, bonuses)                                                       | `teacher_payrolls`                                                       |
| Payroll workflow         | Draft → Approved → Paid status lifecycle                                                                                                              | `teacher_payrolls.status`                                                |
| Financial dashboards     | Revenue, outstanding receivables, expenses, P&L, ROI per branch                                                                                       | Aggregates across `invoices`, `payments`, `expenses`, `teacher_payrolls` |

#### 5.2.9. Communication Management

| Feature                | Description                                                                                                                                    | Primary tables           |
| ---------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------ |
| Notification templates | Create message templates per channel (SMS/Telegram/email) and locale (uz/ru/en) with variable interpolation (`{{studentName}}`, `{{dueDate}}`) | `notification_templates` |
| Payment reminder rules | Configure automated reminders: "3 days before due on Telegram, on due date via SMS, 1 day overdue via SMS"                                     | `payment_reminder_rules` |
| Notification log       | View delivery history: queued, sent, delivered, failed — with provider message IDs and errors                                                  | `notifications`          |
| Manual broadcast       | Send one-off notifications to a group/branch/all students                                                                                      | `notifications`          |

#### 5.2.10. Audit & Settings

| Feature            | Description                                                                                     | Primary tables    |
| ------------------ | ----------------------------------------------------------------------------------------------- | ----------------- |
| Activity audit log | Searchable log of all privileged actions with actor, entity, before/after snapshots, IP address | `audit_logs`      |
| Tenant settings    | Branding, default locale, timezone, integration keys                                            | `tenant_settings` |
| Branch settings    | Per-branch timezone, address, contact info, active/inactive toggle                              | `branches`        |

---

### 5.3. Teacher App (Web / Mobile PWA)

**Audience:** Teachers and instructors.

**Purpose:** Focused daily workflow — take attendance, enter grades, share materials.

| Feature                 | Description                                                                                                      | Primary tables                                  |
| ----------------------- | ---------------------------------------------------------------------------------------------------------------- | ----------------------------------------------- |
| My schedule             | View personal session calendar (today / this week) filtered to the teacher's assigned groups                     | `sessions` (filtered by `teacher_id`)           |
| Take attendance         | Per-session student roster; mark present/absent/late/excused with optional notes                                 | `attendances`                                   |
| My groups               | View all assigned groups with student rosters and enrollment statuses                                            | `groups`, `enrollments`, `students`             |
| Create assessment       | Create quizzes/exams for a group with max score, date, type, grading scale, and weight                           | `assessments`                                   |
| Enter grades            | Enter/edit scores and feedback per student for an assessment; system derives grade labels from the grading scale | `assessment_results`                            |
| Publish results         | Toggle assessment visibility to students/parents                                                                 | `assessments.is_published`                      |
| Leaderboard view        | Ranked student performance with optional percentile display                                                      | `assessment_results.percentile_rank`            |
| Share materials         | Upload PDFs, videos, homework links to a group with visibility control (group/branch/tenant)                     | `learning_materials`                            |
| Session notes           | Add topic covered and session-level notes                                                                        | `sessions.topic`                                |
| Student profiles (read) | View student contact info, emergency contact, attendance history, grade history                                  | `students`, `attendances`, `assessment_results` |

---

### 5.4. Student & Parent Portal (Telegram Bot / Mobile PWA)

**Audience:** Students and their parents/guardians.

**Purpose:** Stay informed — schedule, grades, invoices, notifications — without
needing to call the center.

| Feature            | Description                                                                                                      | Primary tables                                    |
| ------------------ | ---------------------------------------------------------------------------------------------------------------- | ------------------------------------------------- |
| My schedule        | View upcoming sessions: date, time, room, teacher, topic                                                         | `enrollments` → `groups` → `sessions`             |
| Attendance history | View personal attendance record per group/session with status and notes                                          | `attendances`                                     |
| My grades          | View assessment scores, grade labels, teacher feedback per subject/group                                         | `assessment_results`, `assessments`               |
| Learning materials | Access shared files, homework, and videos for enrolled groups                                                    | `learning_materials`                              |
| My invoices        | View invoices with line items, due dates, status, and balance                                                    | `invoices`, `invoice_line_items`                  |
| Pay online         | Initiate payment via Click/Payme/Uzum directly from an invoice                                                   | `payments`                                        |
| Payment history    | View past payments with amounts, dates, and methods                                                              | `payments`                                        |
| Notification inbox | Receive automated and manual notifications: payment reminders, absence alerts, grade published, schedule changes | `notifications`                                   |
| Profile management | Update phone, email, preferred language, Telegram link                                                           | `users`                                           |
| Parent view        | Guardians see a combined dashboard for all linked children's schedules, grades, and invoices                     | `student_guardians` → `students` → all child data |

---

## 7. API Endpoints

Each platform surface gets its own URL prefix with its own controllers. The RBAC guard on each prefix enforces who can access it, and each controller is tailored to its audience's data shape and workflow.

| Endpoint          | Description             | Permissions                             |
| ----------------- | ----------------------- | --------------------------------------- |
| /api/v1/admin/\*  | Super Admin Panel       | (requires: SUPER ADMIN role)            |
| /api/v1/manage/\* | Staff Web App           | (requires: OWNER, ADMIN, MANAGER role)  |
| /api/v1/teach/\*  | Teacher App             | (requires: TEACHER role)                |
| /api/v1/portal/\* | Student & Parent Portal | (requires: STUDENT, PARENT role)        |
| /api/v1/public/\* | Unauthenticated         | (webhooks, health check, tenant signup) |

## 6. Core Modules & Features

Below is the same feature set organized by **backend module** rather than by client surface,
showing how each NestJS module maps to the database tables and serves all four
surfaces.

### 6.1. Identity & Access Management

Handles authentication, tenant membership, and authorization.

- **Global user identity** — one login per person reusable across tenants (`users`).
- **Tenant membership** — records which tenants a user belongs to (`tenant_users`).
- **JWT authentication** — access + refresh token flow with Argon2 password hashing.
- **RBAC** — roles scoped per tenant, optionally per branch, with granular permission
  codes (`roles`, `permissions`, `role_permissions`, `user_role_assignments`).
- **System roles** — default templates (OWNER, ADMIN, TEACHER, STUDENT, PARENT) shipped
  to every new tenant; centers can add custom roles.

### 6.2. Student & Personnel Management

- **Student lifecycle** — registration with auto-generated codes, profile management,
  guardian linking, status transitions, soft-delete (`students`, `student_guardians`).
- **Staff lifecycle** — registration, department/specialization/salary, employment type,
  status (`staff`).
- **Cross-branch flexibility** — a user can hold different roles at different branches.

### 6.3. CRM & Lead Pipeline

- **Lead capture** from multiple sources with assigned follow-up staff (`leads`).
- **Activity tracking** — call/message/trial/note log per lead (`lead_activities`).
- **Pipeline visualization** — status-based funnel (NEW → ENROLLED / LOST).
- **Conversion** — one-click lead-to-student flow.

### 6.4. Academics & Scheduling

- **Course catalog** with levels and default durations (`courses`).
- **Groups/cohorts** tied to a course, teacher, room, and capacity (`groups`).
- **Recurring schedules** — JSONB rule auto-materializes `sessions` on a calendar.
- **Room management** with capacity and conflict detection (`rooms`).
- **Enrollment** — student-to-group binding with fee plan override (`enrollments`).
- **Materials** — file sharing scoped to group/branch/tenant (`learning_materials`).

### 6.5. Assessment & Progress Tracking

- **Attendance** — per-session, per-student, with marker identity and timestamp;
  offline-capable (`attendances`).
- **Custom grading scales** — numeric, percentage, letter, or band (e.g. IELTS) via
  JSONB configuration (`grading_scales`).
- **Assessments** — quizzes, midterms, finals, mock exams, homework (`assessments`).
- **Results** — score + derived grade label + optional percentile rank + teacher feedback (`assessment_results`).

### 6.6. Financial & Billing Management

- **Fee plans** — billing templates per branch/course with cycle, due day, late fee, grace period (`fee_plans`).
- **Invoicing** — automated generation with line items; full lifecycle
  (draft/unpaid/partial/paid/overdue/void/refunded) (`invoices`,
  `invoice_line_items`).
- **Discounts** — percentage or fixed, promo codes, usage caps, validity windows (`discounts`, `invoice_discounts`).
- **Payments** — multi-method (cash + Click/Payme/Uzum/card/bank) with provider txn tracking and idempotent webhook handling (`payments`).
- **Expense tracking** — categorized per branch with receipt uploads (`expenses`).
- **Payroll** — per-teacher period with gross/deductions/net + breakdown; approval workflow (`teacher_payrolls`).

### 6.7. Communication & Notifications

- **Templates** — per channel (SMS/Telegram/email/push) and locale (uz/ru/en) with variable interpolation (`notification_templates`).
- **Outbox pattern** — queued → sent → delivered/failed; worker drains to providers (`notifications`).
- **Payment reminders** — rule-based automation at configurable day offsets relative to invoice due dates (`payment_reminder_rules`).
- **Triggered events** — absence alert, grade published, invoice issued, payment received, schedule change.

### 6.8. Reporting & Dashboards

Built from aggregates across the tables above (no dedicated reporting tables needed):

- **Academic** — attendance rates per group/branch/student; assessment pass rates; score distributions.
- **Financial** — monthly revenue; outstanding receivables; overdue breakdown; P&L per branch; teacher payroll totals.
- **CRM** — lead funnel conversion rates; source effectiveness; time-to-enroll.
- **Operational** — group fill rates; room utilization; teacher workload.

---

## 7. Data Model Summary

40 tables across 8 domain groups. Every tenant-scoped table carries `tenant_id` enforced by RLS.

| Domain          | Tables                                                                                                                      | Count  |
| --------------- | --------------------------------------------------------------------------------------------------------------------------- | ------ |
| Platform        | `subscription_tiers`, `tenants`, `subscriptions`, `branches`, `tenant_settings`, `audit_logs`                               | 6      |
| Identity & RBAC | `users`, `tenant_users`, `roles`, `permissions`, `role_permissions`, `user_role_assignments`                                | 6      |
| People          | `students`, `staff`, `student_guardians`                                                                                    | 3      |
| CRM             | `leads`, `lead_activities`                                                                                                  | 2      |
| Academics       | `courses`, `rooms`, `groups`, `sessions`, `enrollments`, `learning_materials`                                               | 6      |
| Assessment      | `grading_scales`, `attendances`, `assessments`, `assessment_results`                                                        | 6      |
| Finance         | `fee_plans`, `invoices`, `invoice_line_items`, `payments`, `discounts`, `invoice_discounts`, `expenses`, `teacher_payrolls` | 8      |
| Communication   | `notification_templates`, `notifications`, `payment_reminder_rules`                                                         | 3      |
| **Total**       |                                                                                                                             | **40** |

See `schema.sql` for the full DDL and `erd.mermaid` for the relationship diagram.

---

## 8. Key Design Decisions

| Decision                                | Rationale                                                                                                                                                                                                             |
| --------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Auto-increment integer primary keys** | Simple, compact, sequential. Human-facing codes (`student_code`, `invoice_number`) serve as stable external identifiers.                                                                                              |
| **`tenant_id` on every row**            | Even when `branch_id` is present — enables a single uniform RLS policy and `tenant_id`-leading indexes on every table.                                                                                                |
| **PostgreSQL Row-Level Security**       | Database-level guarantee that a buggy query can't return another tenant's rows. App filtering is layer 1; RLS is layer 2.                                                                                             |
| **Soft deletes**                        | `deleted_at` on operational tables for recovery and audit trails. Per-tenant unique codes use partial indexes (`WHERE deleted_at IS NULL`) so codes are reusable after deletion.                                      |
| **`numeric(14,2)` for money**           | Avoids floating-point rounding. Default currency UZS.                                                                                                                                                                 |
| **JSONB for flexible config**           | `subscription_tiers.features`, `groups.schedule_rule`, `grading_scales.config`, `teacher_payrolls.breakdown`, `students.emergency_contact` — structured data that varies by context without requiring schema changes. |
| **Idempotent payments**                 | `payments.idempotency_key` (unique per tenant) deduplicates retried Click/Payme/Uzum webhooks.                                                                                                                        |
| **Notification outbox pattern**         | Notifications are written as rows, then drained by workers — reliable even if the SMS/Telegram provider is temporarily down.                                                                                          |
| **Modular monolith**                    | Faster to build and deploy than microservices; module boundaries (NestJS modules) are the future split points.                                                                                                        |

---

## 9. Repository Structure

```
.
├── docs/
│   ├── project-overview.md              ← you are here
│   ├── education-platform-srs.md        # full SRS + architecture spec
│   ├── erd.mermaid                      # entity-relationship diagram
│   └── schema.sql                       # complete PostgreSQL DDL
│
└── src/
    ├── common/
    │   ├── entities/
    │   │   └── tenant-base.entity.ts    # BaseEntity, SoftDeleteEntity, TenantBaseEntity
    │   ├── numeric.transformer.ts       # Postgres numeric → JS number
    │   └── tenant-context/
    │       ├── tenant-context.ts        # AsyncLocalStorage store
    │       ├── tenant.middleware.ts      # subdomain + JWT → tenantId resolution
    │       ├── tenant.subscriber.ts     # auto-stamps tenantId on insert
    │       └── tenant-transaction.runner.ts  # SET LOCAL for RLS
    │
    ├── platform/entities/               # tenants, branches, subscriptions, audit
    ├── identity/entities/               # users, memberships, roles, permissions
    ├── people/entities/                 # students, staff, guardians
    ├── crm/entities/                    # leads, lead activities
    ├── academics/entities/              # courses, groups, sessions, enrollments, materials
    ├── assessment/entities/             # grading scales, attendance, assessments, report cards
    ├── finance/entities/                # fee plans, invoices, payments, discounts, expenses, payroll
    ├── communication/entities/          # templates, notifications, reminder rules
    └── db/migrations/                   # RLS migration
```

---

## 10. Roadmap & Phasing

### Phase 1 — MVP

**Goal:** Replace spreadsheets for a single education center.

**Surfaces:** Staff Web App + Telegram Bot for parents.

**Modules delivered:**

- Identity & RBAC (login, roles, permissions)
- Student & staff management (registration, profiles, guardians)
- Academics & scheduling (courses, groups, sessions, enrollments, rooms)
- Attendance (teacher marks, admin views)
- Basic billing (fee plans, invoices, manual payments, cash recording)
- Telegram notifications (absence alerts, payment reminders)

### Phase 2 — Financial Automation

- Click / Payme / Uzum payment gateway integrations with webhook handling
- Automated invoice generation (monthly cycle)
- Discount management and promo codes
- Expense tracking
- Financial dashboards (revenue, outstanding, P&L)

### Phase 3 — Academic Depth

- Custom grading scales
- Assessment management with weighted scoring
- Learning materials sharing
- Teacher app (dedicated mobile PWA for attendance + grading)

### Phase 4 — Growth & Scale

- CRM / lead pipeline with activity tracking
- Teacher payroll with approval workflow
- Multi-branch management and cross-branch reporting
- Super Admin panel with tenant lifecycle, subscription billing, platform analytics
- SMS provider integration (Eskiz / Play Mobile)
- Student/parent mobile app (if Telegram bot proves limiting)

### Phase 5 — Ecosystem

- Referral program (feature-flagged per subscription tier)
- API for third-party integrations
- Advanced analytics and data export
- Multi-currency support
- Per-database tenant extraction for enterprise customers
