import { Column, Entity, JoinColumn, ManyToOne } from 'typeorm';
import { SoftDeleteEntity } from '~common/base/base.entity';
import { Student } from '~domain/people/entities/student.entity';

export enum InvoiceStatus {
  DRAFT = 'draft',
  ISSUED = 'issued',
  PARTIALLY_PAID = 'partially_paid',
  PAID = 'paid',
  OVERDUE = 'overdue',
  CANCELLED = 'cancelled',
}

/** Customer invoice. invoice_number is unique per tenant. student FK -> students. */
@Entity('invoices')
export class Invoice extends SoftDeleteEntity {
  @Column()
  branchId: string;

  @Column({ length: 40 })
  invoiceNumber: string;

  @Column()
  studentId: string;

  @ManyToOne(() => Student, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'studentId' })
  student: Student;

  @Column({ nullable: true })
  enrollmentId?: string | null;

  @Column({ nullable: true })
  feePlanId?: string | null;

  @Column({ type: 'date', nullable: true })
  periodStart?: string;

  @Column({ type: 'date', nullable: true })
  periodEnd?: string;

  @Column({ type: 'date', default: () => 'CURRENT_DATE' })
  issueDate: string;

  @Column({ type: 'date' })
  dueDate: string;

  @Column('numeric', { precision: 14, scale: 2, default: 0 })
  subtotal: number;

  @Column('numeric', { precision: 14, scale: 2, default: 0 })
  discountAmount: number;

  @Column('numeric', { precision: 14, scale: 2, default: 0 })
  taxAmount: number;

  @Column('numeric', { precision: 14, scale: 2, default: 0 })
  total: number;

  @Column('numeric', { precision: 14, scale: 2, default: 0 })
  amountPaid: number;

  @Column({ length: 3, default: 'UZS' })
  currency: string;

  @Column({ type: 'varchar', length: 20, default: 'DRAFT' })
  status: InvoiceStatus;

  @Column({ type: 'text', nullable: true })
  notes?: string;

  @Column({ nullable: true })
  createdByUserId?: string | null;
}
