import { Column, Entity } from 'typeorm';
import { SoftDeleteEntity } from '~common/base/base.entity';

export enum SalaryRecordStatus {
  CALCULATED = 'calculated',
  APPROVED = 'approved',
  PAID = 'paid',
}

export enum StaffPayrollStatus {
  DRAFT = 'DRAFT',
  APPROVED = 'APPROVED',
  PAID = 'PAID',
}

/**
 * Teacher/staff payroll run. FK correctly references staff.
 */
@Entity('staffPayrolls')
export class StaffPayroll extends SoftDeleteEntity {
  @Column()
  branchId: string;

  @Column()
  staffId: string;

  @Column({ type: 'date' })
  periodStart: string;

  @Column({ type: 'date' })
  periodEnd: string;

  @Column('numeric', { precision: 14, scale: 2, default: 0 })
  grossAmount: number;

  @Column('numeric', { precision: 14, scale: 2, default: 0 })
  deductions: number;

  @Column('numeric', { precision: 14, scale: 2, default: 0 })
  netAmount: number;

  @Column({ type: 'varchar', length: 20, default: 'DRAFT' })
  status: StaffPayrollStatus;

  @Column({ type: 'jsonb', nullable: true })
  breakdown?: Record<string, unknown>; // { hoursTaught, rate, bonuses }

  @Column({ nullable: true })
  approvedByUserId?: string | null;

  @Column({ type: 'timestamptz', nullable: true })
  paidAt?: Date | null;
}
