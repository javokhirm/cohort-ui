import { Column, Entity } from 'typeorm';
import { SoftDeleteEntity } from '~common/base/base.entity';

export enum DiscountType {
  PERCENTAGE = 'PERCENTAGE',
  FIXED_AMOUNT = 'FIXED_AMOUNT',
}

/**
 * Reusable discount/promo definition.
 */
@Entity('discounts')
export class Discount extends SoftDeleteEntity {
  @Column({ length: 100 })
  name: string;

  @Column({ type: 'varchar', length: 20 })
  type: DiscountType;

  @Column('numeric', { precision: 12, scale: 2 })
  value: number;

  @Column({ length: 30, default: 'invoice' })
  applicableTo: string; // 'invoice' | 'fee_plan'

  @Column({ length: 50, nullable: true })
  code?: string | null; // promo code

  @Column({ type: 'int', nullable: true })
  maxUses?: number | null; // NULL = unlimited

  @Column({ type: 'int', default: 0 })
  currentUses: number;

  @Column({ type: 'date', nullable: true })
  validFrom?: string;

  @Column({ type: 'date', nullable: true })
  validUntil?: string;

  @Column({ default: true })
  isActive: boolean;
}
