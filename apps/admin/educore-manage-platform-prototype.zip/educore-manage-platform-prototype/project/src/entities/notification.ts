import { Column, Entity } from 'typeorm';
import { SoftDeleteEntity } from '~common/base/base.entity';

export enum NotificationChannel {
  SMS = 'sms',
  TELEGRAM = 'telegram',
  PUSH = 'push',
  EMAIL = 'email',
}

export enum NotificationStatus {
  QUEUED = 'queued',
  SENT = 'sent',
  DELIVERED = 'delivered',
  FAILED = 'failed',
}

/**
 * Outbox / delivery log — one row per message dispatched (or scheduled).
 * A worker drains QUEUED rows to the SMS/Telegram providers and updates status
 * from provider webhooks. High-volume: partition by createdAt monthly.
 */
@Entity('notifications')
export class Notification extends SoftDeleteEntity {
  @Column({ nullable: true })
  branchId?: string | null;

  @Column({ nullable: true })
  recipientUserId?: string | null;

  @Column({ length: 32, nullable: true })
  recipientPhone?: string; // denormalized at send time

  @Column({ type: 'varchar', length: 20 })
  channel: NotificationChannel;

  @Column({ nullable: true })
  templateId?: string | null;

  @Column({ type: 'jsonb', nullable: true })
  payload?: Record<string, unknown>; // rendered variables / final body

  @Column({ type: 'varchar', length: 20, default: 'QUEUED' })
  status: NotificationStatus;

  @Column({ length: 50, nullable: true })
  provider?: string; // 'eskiz' | 'playmobile' | 'telegram'

  @Column({ length: 255, nullable: true })
  providerMessageId?: string;

  @Column({ type: 'text', nullable: true })
  error?: string;

  @Column({ type: 'timestamptz', nullable: true })
  scheduledAt?: Date | null;

  @Column({ type: 'timestamptz', nullable: true })
  sentAt?: Date | null;
}
