import { Column, Entity } from 'typeorm';
import { SoftDeleteEntity } from '~common/base/base.entity';

/**
 * Operating expense for ROI/P&L tracking.
 */
@Entity('expenses')
export class Expense extends SoftDeleteEntity {
  @Column()
  branchId: string;

  @Column({ length: 50 })
  category: string; // 'RENT' | 'UTILITIES' | 'MARKETING' | 'SALARY' | 'OTHER'

  @Column('numeric', { precision: 14, scale: 2 })
  amount: number;

  @Column({ length: 3, default: 'UZS' })
  currency: string;

  @Column({ type: 'date' })
  expenseDate: string;

  @Column({ length: 255, nullable: true })
  vendor?: string;

  @Column({ type: 'text', nullable: true })
  description?: string;

  @Column({ length: 512, nullable: true })
  receiptUrl?: string;

  @Column({ nullable: true })
  recordedByUserId?: string | null;
}
