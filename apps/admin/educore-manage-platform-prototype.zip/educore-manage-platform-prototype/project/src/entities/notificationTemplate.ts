import { Column, Entity } from 'typeorm';
import { SoftDeleteEntity } from '~common/base/base.entity';
import { NotificationChannel } from './notification';

/** Reusable message template with variable interpolation, per channel + locale. */
@Entity('notificationTemplates')
export class NotificationTemplate extends SoftDeleteEntity {
  @Column({ length: 100 })
  code: string; // 'INVOICE_DUE', 'ABSENCE_ALERT', 'WELCOME'

  @Column({ type: 'varchar', length: 20 })
  channel: NotificationChannel;

  @Column({ length: 5, default: 'uz' })
  locale: string;

  @Column({ length: 255, nullable: true })
  subject?: string; // email only

  @Column({ type: 'text' })
  body: string; // "Hurmatli {{parentName}}, {{studentName}} darsga kelmadi."

  @Column({ default: true })
  isActive: boolean;
}
