import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn } from 'typeorm';

/**
 * Immutable audit trail. tenantId is nullable for platform-wide / super-admin actions.
 * High-volume: partition by createdAt (monthly) in production.
 */
@Entity('auditLogs')
export class AuditLog {
  @PrimaryGeneratedColumn()
  id: string;

  @Column({ nullable: true })
  tenantId?: string | null;

  @Column({ nullable: true })
  actorUserId?: string | null;

  @Column({ length: 100 })
  action: string; // 'BATCH_DELETE_STUDENTS', 'INVOICE_VOIDED'

  @Column({ length: 100, nullable: true })
  entityType?: string; // 'Invoice', 'Student'

  @Column({ nullable: true })
  entityId?: string | null;

  @Column({ type: 'jsonb', nullable: true })
  before?: Record<string, unknown> | null;

  @Column({ type: 'jsonb', nullable: true })
  after?: Record<string, unknown> | null;

  @Column({ length: 64, nullable: true })
  ipAddress?: string;

  @CreateDateColumn({ type: 'timestamptz' })
  createdAt: Date;
}
