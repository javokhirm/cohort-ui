import { Column, Entity } from 'typeorm';
import { SoftDeleteEntity } from '~common/base/base.entity';

export enum PaymentMethod {
  CASH = 'cash',
  BANK_TRANSFER = 'bank_transfer',
  CLICK = 'click',
  PAYME = 'payme',
  UZUM = 'uzum',
  OTHER = 'other',
}

export enum PaymentStatus {
  PENDING = 'pending',
  COMPLETED = 'completed',
  FAILED = 'failed',
  REFUNDED = 'refunded',
}

/**
 * Payment against an invoice. Includes fintech fields for Click/Payme/Uzum:
 * provider transaction id, status, and an idempotency key to safely dedupe
 * webhook retries.
 */
@Entity('payments')
export class Payment extends SoftDeleteEntity {
  @Column()
  branchId: string;

  @Column({ nullable: true })
  invoiceId?: string | null; // nullable for advance/credit payments

  @Column()
  studentId: string;

  @Column('numeric', { precision: 14, scale: 2 })
  amount: number;

  @Column({ length: 3, default: 'UZS' })
  currency: string;

  @Column({ type: 'varchar', length: 20 })
  method: PaymentMethod;

  @Column({ type: 'varchar', length: 20, default: 'PENDING' })
  status: PaymentStatus;

  @Column({ length: 255, nullable: true })
  providerTxnId?: string;

  @Column({ length: 255, nullable: true })
  idempotencyKey?: string | null;

  @Column({ type: 'timestamptz', nullable: true })
  paidAt?: Date | null;

  @Column({ nullable: true })
  receivedByUserId?: string | null;

  @Column({ type: 'text', nullable: true })
  notes?: string;
}
