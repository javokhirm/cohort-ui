import { Column, Entity } from 'typeorm';
import { SoftDeleteEntity } from '~common/base/base.entity';

export enum BillingCycle {
  MONTHLY = 'MONTHLY',
  QUARTERLY = 'QUARTERLY',
  ONE_TIME = 'ONE_TIME',
  PER_SESSION = 'PER_SESSION',
}

/** Billing template applied to enrollments/invoices. */
@Entity('feePlans')
export class FeePlan extends SoftDeleteEntity {
  @Column({ nullable: true })
  branchId?: string | null;

  @Column({ nullable: true })
  courseId?: string | null;

  @Column({ length: 255 })
  name: string; // "Monthly Tuition — IELTS"

  @Column('numeric', { precision: 14, scale: 2 })
  amount: number;

  @Column({ length: 3, default: 'UZS' })
  currency: string;

  @Column({ type: 'varchar', length: 20, default: 'MONTHLY' })
  billingCycle: BillingCycle;

  @Column({ type: 'smallint', default: 1 })
  dueDay: number; // 1-28

  @Column('numeric', { precision: 12, scale: 2, default: 0 })
  lateFeeAmount: number;

  @Column({ type: 'smallint', default: 3 })
  gracePeriodDays: number;

  @Column({ default: true })
  isActive: boolean;
}
