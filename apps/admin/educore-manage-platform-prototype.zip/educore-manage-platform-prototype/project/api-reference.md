# EduCore — API Reference

> **Status:** Finalized. Matches the confirmed folder structure and `schema.sql`.
> This document is the source of truth for every HTTP endpoint in the system. When
> implementing a controller, follow this spec — do not invent endpoints.

## Table of Contents

- [Conventions](#conventions)
- [1. Public API](#1-public-api-apiv1public) — auth, webhooks, health
- [2. Super Admin API](#2-super-admin-api-apiv1admin) — tenant lifecycle, subscriptions, platform monitoring
- [3. Staff (Manage) API](#3-staff-manage-api-apiv1manage) — full back-office
- [4. Teacher API](#4-teacher-api-apiv1teach) — daily teaching workflow
- [5. Student & Parent Portal API](#5-student--parent-portal-api-apiv1portal) — self-service
- [Appendix A: Enums & Status Values](#appendix-a-enums--status-values)
- [Appendix B: Standard Response Envelope](#appendix-b-standard-response-envelope)
- [Appendix C: Pagination](#appendix-c-pagination)

---

## Conventions

### Authentication

All endpoints except `/api/v1/public/*` require a valid JWT in the `Authorization:
Bearer <token>` header. The JWT payload contains:

```json
{
  "sub": "<userId>",
  "tenantId": "<tenantId>",
  "roles": ["OWNER", "ADMIN"],
  "branchScope": ["<branchId>", "..."]
}
```

### Tenant Resolution

- **Tenant** is resolved from the request subdomain (`zabon.educore.uz`) and
  cross-checked against the JWT `tenantId`. Mismatch → 401.
- **Branch** is a query parameter (`?branchId=<id>`) for list endpoints.
  - If omitted and the user has multi-branch access → returns data across all
    accessible branches.
  - If omitted and the user is branch-scoped → auto-filtered to their branch.
  - If provided but the user lacks access to that branch → 403.

### HTTP Methods

| Method   | Semantics                                                                  |
| -------- | -------------------------------------------------------------------------- |
| `GET`    | Read. Never mutates.                                                       |
| `POST`   | Create a new resource, or trigger an action (e.g. `/convert`, `/publish`). |
| `PATCH`  | Partial update. Send only the fields to change.                            |
| `PUT`    | Full replacement of a sub-resource (e.g. replace a role's permission set). |
| `DELETE` | Soft-delete (sets `deleted_at`). Returns 204 No Content.                   |

### ID Format

All `:id` path parameters are integers. Invalid (non-integer) IDs → 400.

### Timestamps

All timestamps in request/response bodies are ISO 8601 with timezone
(`2025-03-15T10:30:00+05:00`). Dates without time are `YYYY-MM-DD`.

### Money

All monetary amounts are numbers with up to 2 decimal places. Currency is always
explicit in the response; the default is `UZS`.

---

## 1. Public API (`/api/v1/public`)

**Auth:** None (unauthenticated). Webhooks are verified by provider-specific
signatures. Rate-limited aggressively.

### 1.1 Authentication

```
POST   /auth/login
```

Authenticates a user and returns a JWT pair. The tenant is resolved from the request
subdomain (the user is logging into a specific center's portal).

| Field      | Type   | Required | Notes                          |
| ---------- | ------ | -------- | ------------------------------ |
| `phone`    | string | yes      | E.164 format (`+998901234567`) |
| `password` | string | yes      |                                |

**Response 200:**

```json
{
  "accessToken": "eyJ...",
  "refreshToken": "eyJ...",
  "expiresIn": 900,
  "user": {
    "id": 1,
    "firstName": "...",
    "lastName": "...",
    "roles": ["TEACHER"],
    "branchScope": [1]
  }
}
```

**Clarification:** If the user belongs to multiple tenants, they log in via the
specific tenant's subdomain. The response includes only the roles for _that_ tenant.

---

```
POST   /auth/refresh
```

Exchanges a valid refresh token for a new JWT pair.

| Field          | Type   | Required |
| -------------- | ------ | -------- |
| `refreshToken` | string | yes      |

**Response 200:** Same shape as login.

**Clarification:** Refresh tokens are single-use (rotated on each refresh). Using a
revoked refresh token invalidates the entire token family (replay detection).

---

```
POST   /auth/forgot-password
```

Sends a password-reset OTP to the user's phone via SMS or Telegram.

| Field   | Type   | Required |
| ------- | ------ | -------- |
| `phone` | string | yes      |

**Response 200:** `{ "message": "OTP sent" }` — always returns 200 even if the phone
doesn't exist (prevents enumeration).

---

```
POST   /auth/reset-password
```

Resets password using the OTP.

| Field         | Type   | Required |
| ------------- | ------ | -------- |
| `phone`       | string | yes      |
| `otp`         | string | yes      |
| `newPassword` | string | yes      |

---

### 1.2 Payment Gateway Webhooks

```
POST   /webhooks/click
POST   /webhooks/payme
POST   /webhooks/uzum
```

**Auth:** No JWT. Verified by provider-specific signature headers.

**Clarification:**

- Each provider sends a different payload format. The `webhook-verifier.service.ts`
  validates the signature before processing.
- The handler looks up the payment by `idempotencyKey`; if already processed
  (status ≠ PENDING), it returns 200 without re-processing (idempotent).
- On success: payment status → `SUCCEEDED`, invoice `amountPaid` is incremented,
  invoice status recalculated (PARTIAL or PAID), `PaymentReceivedEvent` emitted.
- On failure: payment status → `FAILED`, no invoice change.

---

### 1.3 Health

```
GET    /health
```

**Response 200:** `{ "status": "ok", "version": "1.0.0", "timestamp": "..." }`

Used by load balancers and monitoring. Checks DB + Redis connectivity.

---

## 2. Super Admin API (`/api/v1/admin`)

**Auth:** `SuperAdminGuard` — requires a user with the `SUPER_ADMIN` system
role. This guard uses a **BYPASSRLS** database role so queries are cross-tenant.

**Clarification:** This surface is for your platform operations team only. It is never exposed to education center users.

### 2.1 Tenant Lifecycle

```
GET    /tenants
```

List all education centers on the platform.

| Query Param | Type   | Default | Notes                                         |
| ----------- | ------ | ------- | --------------------------------------------- |
| `status`    | string | (all)   | `ACTIVE`, `SUSPENDED`, `PENDING`, `CANCELLED` |
| `search`    | string |         | Matches against `name` or `subdomain`         |
| `page`      | int    | 1       |                                               |
| `limit`     | int    | 20      | max 100                                       |

---

```
POST   /tenants
```

Onboard a new education center. Creates the tenant, the first (main) branch, and the
owner user in a single transaction.

| Field                | Type   | Required | Notes                                              |
| -------------------- | ------ | -------- | -------------------------------------------------- |
| `name`               | string | yes      | Center's business name                             |
| `subdomain`          | string | yes      | Unique, lowercase, alphanumeric + hyphens          |
| `timezone`           | string | no       | Default: `Asia/Tashkent`                           |
| `defaultCurrency`    | string | no       | Default: `UZS`                                     |
| `subscriptionTierId` | number | no       |                                                    |
| `mainBranch`         | object | yes      | `{ name, code, address?, phone?, email? }`         |
| `ownerUser`          | object | yes      | `{ phone, email?, firstName, lastName, password }` |

**Side effects:**

1. Creates `tenants` row (status = `PENDING`).
2. Creates `branches` row (isMain = true).
3. Creates `users` row (or links existing if phone already exists globally).
4. Creates `tenant_users` membership.
5. Creates `user_role_assignments` with system role `OWNER`.
6. Creates `tenant_settings` with empty defaults.
7. Emits `TenantCreatedEvent`.

---

```
GET    /tenants/:id
```

Full tenant detail including branches, current subscription, and usage stats.

---

```
PATCH  /tenants/:id
```

Update tenant properties or change status.

| Field                | Type   | Notes                                                                                                      |
| -------------------- | ------ | ---------------------------------------------------------------------------------------------------------- |
| `name`               | string |                                                                                                            |
| `status`             | string | `ACTIVE`, `SUSPENDED`, `CANCELLED` — transitioning to `SUSPENDED` immediately blocks all tenant API access |
| `subscriptionTierId` | number |                                                                                                            |
| `timezone`           | string |                                                                                                            |

**Clarification:** Suspending a tenant does not delete data. The `TenantContextGuard`
checks tenant status on every authenticated request; suspended tenants receive 403.

---

```
GET    /tenants/:id/branches
```

List all branches for a specific tenant.

---

```
GET    /tenants/:id/stats
```

Per-tenant health metrics: active students, active staff, monthly revenue, outstanding
balance, last login timestamp.

---

### 2.2 Subscription Tiers

```
GET    /subscription-tiers
POST   /subscription-tiers
PATCH  /subscription-tiers/:id
```

Standard CRUD for the global plan catalog.

| Field (create/update) | Type    | Notes                                                               |
| --------------------- | ------- | ------------------------------------------------------------------- |
| `name`                | string  | `Basic`, `Premium`, `Enterprise`                                    |
| `features`            | object  | `{ "maxBranches": 3, "mockExams": true, "referralProgram": false }` |
| `priceMonthly`        | number  |                                                                     |
| `priceAnnual`         | number  |                                                                     |
| `isActive`            | boolean | Deactivated tiers can't be assigned to new tenants                  |

---

### 2.3 Subscriptions

```
GET    /subscriptions
```

List all active subscriptions across tenants.

| Query Param | Type   | Notes                                         |
| ----------- | ------ | --------------------------------------------- |
| `status`    | string | `TRIALING`, `ACTIVE`, `PAST_DUE`, `CANCELLED` |
| `tierId`    | number | Filter by tier                                |

---

### 2.4 Platform Audit & Dashboard

```
GET    /audit-logs
```

Cross-tenant audit trail. Supports the same query params as the tenant-level audit
(see §3.12) plus `tenantId` filter.

---

```
GET    /dashboard
```

Platform-wide KPIs.

**Response includes:** total tenants (by status), MRR, ARR, new tenants this month,
churn rate, total active students across all tenants, total revenue processed.

---

## 3. Staff (Manage) API (`/api/v1/manage`)

**Auth:** `TenantRoleGuard(['OWNER', 'ADMIN', 'MANAGER'])`. All endpoints are
tenant-scoped (RLS-enforced). Branch filtering via `?branchId=`.

**Clarification:** This is the largest API surface. It powers the full back-office web
app. Owners see everything; Admins and Managers may be branch-scoped via their
`user_role_assignments.branchId`.

### 3.1 Branches & Settings

```
GET    /branches
```

| Query Param | Type    | Notes |
| ----------- | ------- | ----- |
| `isActive`  | boolean |       |

**Response:** Array of branches the requesting user has access to.

---

```
POST   /branches
```

| Field      | Type    | Required | Notes                             |
| ---------- | ------- | -------- | --------------------------------- |
| `name`     | string  | yes      |                                   |
| `code`     | string  | yes      | Unique per tenant (e.g. `BR-002`) |
| `address`  | string  | no       |                                   |
| `phone`    | string  | no       |                                   |
| `email`    | string  | no       |                                   |
| `timezone` | string  | no       | Overrides tenant default          |
| `isMain`   | boolean | no       | Only one branch can be main       |

**Permission:** `branch.create`

---

```
GET    /branches/:id
PATCH  /branches/:id
```

PATCH fields: `name`, `address`, `phone`, `email`, `timezone`, `isActive`, `isMain`.

**Permission:** `branch.update`

---

```
GET    /settings
PATCH  /settings
```

Reads/updates tenant-level settings (`tenant_settings.settings` JSONB).

**Example settings object:**

```json
{
  "branding": { "logoUrl": "...", "primaryColor": "#1a73e8" },
  "locale": { "defaultLanguage": "uz", "dateFormat": "DD.MM.YYYY" },
  "invoicing": { "numberPrefix": "INV", "autoGenerate": true },
  "notifications": { "absenceAlertEnabled": true }
}
```

**Permission:** `settings.manage`

---

### 3.2 CRM / Lead Pipeline

```
GET    /leads
```

| Query Param         | Type   | Notes                                                              |
| ------------------- | ------ | ------------------------------------------------------------------ |
| `branchId`          | number |                                                                    |
| `status`            | string | `NEW`, `CONTACTED`, `TRIAL_BOOKED`, `ENROLLED`, `LOST`             |
| `source`            | string | `INSTAGRAM`, `TELEGRAM`, `REFERRAL`, `WALK_IN`, `WEBSITE`, `OTHER` |
| `assignedToStaffId` | number |                                                                    |
| `search`            | string | Matches `firstName`, `lastName`, `phoneNumber`                     |
| `page`, `limit`     | int    |                                                                    |

**Permission:** `lead.read`

---

```
POST   /leads
```

| Field               | Type   | Required | Notes         |
| ------------------- | ------ | -------- | ------------- |
| `branchId`          | number | no       |               |
| `firstName`         | string | yes      |               |
| `lastName`          | string | no       |               |
| `phoneNumber`       | string | yes      |               |
| `email`             | string | no       |               |
| `courseInterestId`  | number | no       | FK to courses |
| `source`            | string | yes      |               |
| `assignedToStaffId` | number | no       |               |
| `notes`             | string | no       |               |

**Permission:** `lead.create`

---

```
GET    /leads/:id
PATCH  /leads/:id
```

PATCH fields: all create fields + `status`. Transitioning status to `ENROLLED` does
**not** auto-convert — use the convert endpoint.

**Permission:** `lead.update`

---

```
POST   /leads/:id/convert
```

Converts a lead into an enrolled student.

| Field       | Type   | Required | Notes                                   |
| ----------- | ------ | -------- | --------------------------------------- |
| `branchId`  | number | yes      | Target branch for the student           |
| `groupId`   | number | no       | Optionally enroll directly into a group |
| `feePlanId` | number | no       |                                         |

**Side effects (single transaction):**

1. Creates or links a `users` identity (matched by phone).
2. Creates a `students` profile with auto-generated `studentCode`.
3. Creates `tenant_users` membership if new to this tenant.
4. Creates `user_role_assignments` with role `STUDENT`.
5. If `groupId` provided: creates `enrollments` row.
6. Updates lead status to `ENROLLED`, sets `convertedStudentId`.
7. Emits `LeadConvertedEvent`.

**Response 201:** The created student object.

**Permission:** `lead.convert`

---

```
GET    /leads/:id/activities
POST   /leads/:id/activities
```

Activities are follow-up touchpoints.

| Field (create) | Type     | Required | Notes                              |
| -------------- | -------- | -------- | ---------------------------------- |
| `type`         | string   | yes      | `CALL`, `MESSAGE`, `TRIAL`, `NOTE` |
| `notes`        | string   | no       |                                    |
| `scheduledAt`  | datetime | no       | For follow-up scheduling           |

**Permission:** `lead.activity.create`

---

### 3.3 Student Management

```
GET    /students
```

| Query Param     | Type   | Notes                                                   |
| --------------- | ------ | ------------------------------------------------------- |
| `branchId`      | number |                                                         |
| `status`        | string | `ACTIVE`, `INACTIVE`, `GRADUATED`, `SUSPENDED`          |
| `groupId`       | number | Students enrolled in a specific group                   |
| `search`        | string | Matches `firstName`, `lastName`, `studentCode`, `phone` |
| `enrolledFrom`  | date   |                                                         |
| `enrolledTo`    | date   |                                                         |
| `page`, `limit` | int    |                                                         |

**Response includes:** student profile + user identity fields (name, phone, avatar)
via join.

**Permission:** `student.read`

---

```
POST   /students
```

| Field              | Type   | Required | Notes                             |
| ------------------ | ------ | -------- | --------------------------------- |
| `branchId`         | number | yes      |                                   |
| `firstName`        | string | yes      |                                   |
| `lastName`         | string | yes      |                                   |
| `phone`            | string | yes      | Creates or links a `users` record |
| `email`            | string | no       |                                   |
| `dateOfBirth`      | date   | no       |                                   |
| `gender`           | string | no       | `M`, `F`, `O`                     |
| `address`          | string | no       |                                   |
| `emergencyContact` | object | no       | `{ name, phone, relation }`       |
| `notes`            | string | no       |                                   |

**Side effects:**

1. Creates `users` (or links existing by phone).
2. Creates `students` with auto-generated `studentCode`.
3. Creates `tenant_users` + `user_role_assignments` (STUDENT).

**Clarification:** The `studentCode` is generated as `STU-{YYYY}-{sequence}` and is
unique per tenant. The sequence resets yearly.

**Permission:** `student.create`

---

```
GET    /students/:id
```

Full student detail: profile, user identity, guardians, active enrollments, recent
attendance summary, outstanding invoices count.

**Permission:** `student.read`

---

```
PATCH  /students/:id
```

Updatable fields: `branchId` (transfer), `dateOfBirth`, `gender`, `address`,
`emergencyContact`, `notes`, `status`.

**Clarification:** Changing `status` to `GRADUATED` does not auto-complete enrollments
or generate a final report card — those are separate actions.

**Permission:** `student.update`

---

```
DELETE /students/:id
```

Soft-delete. Sets `deletedAt`. Student code becomes reusable.

**Permission:** `student.delete`

---

```
GET    /students/:id/guardians
```

List linked guardians with relation type, primary flag, pickup permission.

---

```
POST   /students/:id/guardians
```

| Field       | Type    | Required | Notes                                              |
| ----------- | ------- | -------- | -------------------------------------------------- |
| `phone`     | string  | yes      | Creates or links a `users` record for the guardian |
| `firstName` | string  | yes\*    | \*Required if new user                             |
| `lastName`  | string  | yes\*    |                                                    |
| `relation`  | string  | yes      | `mother`, `father`, `guardian`                     |
| `isPrimary` | boolean | no       | Default: false                                     |
| `canPickup` | boolean | no       | Default: true                                      |

**Side effects:** Creates `users` + `tenantUsers` + `userRoleAssignments` (PARENT)
if the guardian is new to this tenant.

**Permission:** `student.guardian.manage`

---

```
DELETE /students/:id/guardians/:guardianId
```

Removes the guardian link (does not delete the guardian's user account).

---

```
GET    /students/:id/enrollments
GET    /students/:id/invoices
GET    /students/:id/payments
GET    /students/:id/attendances
GET    /students/:id/results
```

Convenience sub-resource endpoints. Each returns the relevant records for this
student. All support `page`/`limit` pagination. Attendances and results also support
`from`/`to` date filters.

**Permission:** `student.read` (inherits from student access)

---

### 3.4 Staff & HR

```
GET    /staff
```

| Query Param      | Type   | Notes                                  |
| ---------------- | ------ | -------------------------------------- |
| `branchId`       | number |                                        |
| `department`     | string |                                        |
| `employmentType` | string | `FULL_TIME`, `PART_TIME`, `CONTRACTOR` |
| `status`         | string | `ACTIVE`, `ON_LEAVE`, `TERMINATED`     |
| `search`         | string |                                        |
| `page`, `limit`  | int    |                                        |

**Permission:** `staff.read`

---

```
POST   /staff
```

| Field            | Type     | Required | Notes                                              |
| ---------------- | -------- | -------- | -------------------------------------------------- |
| `branchId`       | number   | yes      |                                                    |
| `firstName`      | string   | yes      |                                                    |
| `lastName`       | string   | yes      |                                                    |
| `phone`          | string   | yes      | Creates or links a `users` record                  |
| `email`          | string   | no       |                                                    |
| `department`     | string   | no       |                                                    |
| `specialization` | string[] | no       | e.g. `["IELTS", "General English"]`                |
| `hireDate`       | date     | no       |                                                    |
| `employmentType` | string   | no       | Default: `FULL_TIME`                               |
| `baseSalary`     | number   | no       |                                                    |
| `roleName`       | string   | no       | Default: `TEACHER`. Can also be `ADMIN`, `MANAGER` |

**Side effects:** Same pattern as student creation — creates/links user, membership,
role assignment.

**Permission:** `staff.create`

---

```
GET    /staff/:id
PATCH  /staff/:id
DELETE /staff/:id
```

PATCH fields: `branchId`, `department`, `specialization`, `employmentType`,
`baseSalary`, `status`.

**Permission:** `staff.update` / `staff.delete`

---

### 3.5 Roles & Permissions (RBAC)

```
GET    /roles
```

Returns both system roles (tenantId = null) and tenant-custom roles.
System roles are read-only.

**Permission:** `role.read`

---

```
POST   /roles
```

Create a custom role for this tenant.

| Field         | Type   | Required |
| ------------- | ------ | -------- |
| `name`        | string | yes      |
| `description` | string | no       |

**Permission:** `role.create`

---

```
PATCH  /roles/:id
```

Update name/description. Cannot modify system roles.

**Permission:** `role.update`

---

```
GET    /roles/:id/permissions
```

Returns the permission codes assigned to a role.

---

```
PUT    /roles/:id/permissions
```

**Full replacement** of the role's permission set.

| Field           | Type     | Required | Notes                             |
| --------------- | -------- | -------- | --------------------------------- |
| `permissionIds` | number[] | yes      | Array of permission IDs to assign |

**Clarification:** This is PUT (replace), not PATCH (merge). Sending an empty array
removes all permissions from the role.

**Permission:** `role.permissions.manage`

---

```
GET    /permissions
```

Returns the full catalog of available permission codes (system-defined, immutable).

---

```
GET    /users/:id/role-assignments
```

Returns all role assignments for a user in this tenant, including branch scope.

---

```
POST   /users/:id/role-assignments
```

| Field      | Type   | Required | Notes                          |
| ---------- | ------ | -------- | ------------------------------ |
| `roleId`   | number | yes      |                                |
| `branchId` | number | no       | Null = applies to all branches |

**Clarification:** A user can hold multiple roles. Assigning `ADMIN` at branch A and
`TEACHER` at branch B gives different permissions at different branches.

**Permission:** `role.assign`

---

```
DELETE /users/:id/role-assignments/:assignmentId
```

Revoke a specific role assignment. Cannot revoke the last `OWNER` role.

**Permission:** `role.assign`

---

### 3.6 Courses & Rooms

```
GET    /courses
POST   /courses
PATCH  /courses/:id
```

| Field (create)         | Type   | Required | Notes                                  |
| ---------------------- | ------ | -------- | -------------------------------------- |
| `branchId`             | number | no       | Null = shared across all branches      |
| `name`                 | string | yes      |                                        |
| `description`          | string | no       |                                        |
| `level`                | string | no       | `Beginner`, `A2`, `Intermediate`, etc. |
| `defaultDurationWeeks` | int    | no       |                                        |

Query: `?branchId=&search=&isActive=`

**Permission:** `course.create` / `course.update`

---

```
GET    /rooms
POST   /rooms
PATCH  /rooms/:id
```

| Field (create) | Type   | Required | Notes                        |
| -------------- | ------ | -------- | ---------------------------- |
| `branchId`     | number | yes      |                              |
| `name`         | string | yes      |                              |
| `capacity`     | int    | yes      |                              |
| `type`         | string | no       | `classroom`, `lab`, `online` |

Query: `?branchId=&isActive=`

**Permission:** `room.create` / `room.update`

---

### 3.7 Groups & Scheduling

```
GET    /groups
```

| Query Param     | Type   | Notes                                         |
| --------------- | ------ | --------------------------------------------- |
| `branchId`      | number |                                               |
| `courseId`      | number |                                               |
| `teacherId`     | number | FK to staff.id                                |
| `status`        | string | `PLANNED`, `ACTIVE`, `COMPLETED`, `CANCELLED` |
| `page`, `limit` | int    |                                               |

**Permission:** `group.read`

---

```
POST   /groups
```

| Field              | Type   | Required | Notes                  |
| ------------------ | ------ | -------- | ---------------------- |
| `branchId`         | number | yes      |                        |
| `courseId`         | number | yes      |                        |
| `defaultTeacherId` | number | no       | FK to staff.id         |
| `roomId`           | number | no       |                        |
| `name`             | string | yes      | e.g. `IELTS Morning A` |
| `capacity`         | int    | no       |                        |
| `startDate`        | date   | no       |                        |
| `endDate`          | date   | no       |                        |
| `scheduleRule`     | object | no       | See below              |

**`scheduleRule` format:**

```json
{
  "days": ["MON", "WED", "FRI"],
  "startTime": "09:00",
  "endTime": "10:30"
}
```

**Side effects:** If `scheduleRule`, `startDate`, and `endDate` are all provided, the
`SessionGeneratorService` materializes individual `sessions` rows for the entire date
range. Sessions can be individually modified afterward.

**Permission:** `group.create`

---

```
GET    /groups/:id
PATCH  /groups/:id
```

PATCH fields: `defaultTeacherId`, `roomId`, `name`, `capacity`, `startDate`,
`endDate`, `scheduleRule`, `status`.

**Clarification:** Updating `scheduleRule` on an active group can optionally regenerate
future sessions (controlled by a `regenerateSessions: true` flag in the body). Past
sessions are never deleted.

**Permission:** `group.update`

---

```
GET    /groups/:id/enrollments
```

List enrolled students with enrollment status. Supports `?status=ACTIVE`.

---

```
POST   /groups/:id/enrollments
```

Enroll one or more students.

| Field        | Type     | Required | Notes                            |
| ------------ | -------- | -------- | -------------------------------- |
| `studentIds` | number[] | yes      | Array for batch enrollment       |
| `feePlanId`  | number   | no       | Per-enrollment fee plan override |

**Validation:** Checks group capacity. Returns 409 if the group is full.

**Side effects:** Emits `EnrollmentCreatedEvent` (the communication module may send a
welcome notification).

**Permission:** `enrollment.create`

---

```
GET    /groups/:id/sessions
```

Sessions for this group. Supports `?from=&to=&status=`.

---

```
GET    /groups/:id/assessments
GET    /groups/:id/materials
```

Convenience endpoints: assessments and materials for this group.

---

```
GET    /sessions
```

**Calendar endpoint.** Returns sessions across all accessible groups.

| Query Param | Type   | Required | Notes                                 |
| ----------- | ------ | -------- | ------------------------------------- |
| `branchId`  | number | no       |                                       |
| `from`      | date   | yes      |                                       |
| `to`        | date   | yes      | Max span: 90 days                     |
| `teacherId` | number | no       |                                       |
| `roomId`    | number | no       |                                       |
| `status`    | string | no       | `SCHEDULED`, `COMPLETED`, `CANCELLED` |

**Response includes:** session + group name + course name + teacher name + room name
(all joined).

**Permission:** `session.read`

---

```
GET    /sessions/:id
```

Full session detail including the student roster (from enrollments).

---

```
PATCH  /sessions/:id
```

| Field                | Type   | Notes                                       |
| -------------------- | ------ | ------------------------------------------- |
| `sessionDate`        | date   | Reschedule                                  |
| `startTime`          | time   |                                             |
| `endTime`            | time   |                                             |
| `roomId`             | number | Room change                                 |
| `teacherId`          | number | Substitute teacher (FK to staff.id)         |
| `topic`              | string |                                             |
| `status`             | string | `CANCELLED` — requires `cancellationReason` |
| `cancellationReason` | string | Required when status = `CANCELLED`          |

**Validation:** Conflict detection checks room and teacher availability on the target
date/time. Returns 409 with conflict details if double-booked.

**Side effects:** Cancelling a session emits `SessionCancelledEvent` (triggers
notification to enrolled students/parents).

**Permission:** `session.update`

---

### 3.8 Enrollments

```
GET    /enrollments/:id
PATCH  /enrollments/:id
```

| Field        | Type   | Notes                                                         |
| ------------ | ------ | ------------------------------------------------------------- |
| `status`     | string | `DROPPED` (requires `dropReason`), `COMPLETED`, `TRANSFERRED` |
| `dropReason` | string | Required when status = `DROPPED`                              |

**Clarification:** `TRANSFERRED` means the student is moving to another group. The
admin should create a new enrollment in the target group as a separate action.

**Permission:** `enrollment.update`

---

### 3.9 Attendance (admin view)

```
GET    /attendances
```

| Query Param     | Type   | Notes                                  |
| --------------- | ------ | -------------------------------------- |
| `branchId`      | number |                                        |
| `studentId`     | number |                                        |
| `groupId`       | number |                                        |
| `sessionId`     | number |                                        |
| `status`        | string | `PRESENT`, `ABSENT`, `LATE`, `EXCUSED` |
| `from`          | date   |                                        |
| `to`            | date   |                                        |
| `page`, `limit` | int    |                                        |

**Clarification:** This is a read-only administrative view. Teachers create attendance
records via the Teach API (§4). Admins can view and filter but should not normally
overwrite teacher-submitted data.

**Permission:** `attendance.read`

---

```
GET    /sessions/:id/attendances
```

Attendance records for a specific session with student names.

---

### 3.10 Grading & Assessments (admin view)

```
GET    /grading-scales
POST   /grading-scales
PATCH  /grading-scales/:id
```

| Field (create) | Type    | Required | Notes                                     |
| -------------- | ------- | -------- | ----------------------------------------- |
| `name`         | string  | yes      | e.g. "IELTS Band", "Letter Grade"         |
| `type`         | string  | yes      | `NUMERIC`, `PERCENTAGE`, `LETTER`, `BAND` |
| `config`       | object  | yes      | See examples below                        |
| `isDefault`    | boolean | no       |                                           |

**Config examples:**

```json
// LETTER
{ "bands": [{"min": 90, "label": "A"}, {"min": 80, "label": "B"}, {"min": 70, "label": "C"}, {"min": 0, "label": "F"}] }

// BAND (IELTS)
{ "bands": [{"min": 8.5, "label": "9"}, {"min": 7.5, "label": "8"}, {"min": 6.5, "label": "7"}], "max": 9 }

// PERCENTAGE
{ "passingScore": 60 }
```

**Permission:** `grading-scale.manage`

---

```
GET    /assessments
```

| Query Param | Type   | Notes                                          |
| ----------- | ------ | ---------------------------------------------- |
| `branchId`  | number |                                                |
| `groupId`   | number |                                                |
| `type`      | string | `QUIZ`, `MIDTERM`, `FINAL`, `MOCK`, `HOMEWORK` |
| `from`      | date   | Exam date range                                |
| `to`        | date   |                                                |

---

```
GET    /assessments/:id
GET    /assessments/:id/results
```

Results include: student name, score, grade label, percentile rank, feedback, grader.

**Permission:** `assessment.read`

---

### 3.11 Report Cards

```
GET    /report-cards
```

| Query Param     | Type   | Notes                |
| --------------- | ------ | -------------------- |
| `branchId`      | number |                      |
| `studentId`     | number |                      |
| `groupId`       | number |                      |
| `status`        | string | `DRAFT`, `PUBLISHED` |
| `page`, `limit` | int    |                      |

---

```
POST   /report-cards/generate
```

Triggers report card generation as a background job.

| Field         | Type     | Required | Notes                                 |
| ------------- | -------- | -------- | ------------------------------------- |
| `studentIds`  | number[] | yes      | Batch support — up to 100 per request |
| `groupId`     | number   | yes      |                                       |
| `periodStart` | date     | yes      |                                       |
| `periodEnd`   | date     | yes      |                                       |

**Clarification:** This is an async operation. Returns 202 Accepted with a job ID.
The worker aggregates assessment results and attendance within the period, calculates
overall score/grade using the group's grading scale, generates line items, and
optionally renders a PDF. Report cards are created in `DRAFT` status.

**Permission:** `report-card.generate`

---

```
GET    /report-cards/:id
```

Full detail: student info, period, overall score/grade, attendance rate, line items,
file URL.

---

```
PATCH  /report-cards/:id/publish
```

Transitions status from `DRAFT` to `PUBLISHED`. Sets `publishedAt`.

**Side effects:** Emits `ResultsPublishedEvent` → communication module sends
notification to student and primary guardian.

**Permission:** `report-card.publish`

---

### 3.12 Fee Plans

```
GET    /fee-plans
POST   /fee-plans
PATCH  /fee-plans/:id
```

| Field (create)    | Type   | Required | Notes                                             |
| ----------------- | ------ | -------- | ------------------------------------------------- |
| `branchId`        | number | no       | Null = applies across branches                    |
| `courseId`        | number | no       |                                                   |
| `name`            | string | yes      | "Monthly Tuition — IELTS"                         |
| `amount`          | number | yes      |                                                   |
| `currency`        | string | no       | Default: `UZS`                                    |
| `billingCycle`    | string | yes      | `MONTHLY`, `QUARTERLY`, `ONE_TIME`, `PER_SESSION` |
| `dueDay`          | int    | no       | 1–28, default 1                                   |
| `lateFeeAmount`   | number | no       | Default: 0                                        |
| `gracePeriodDays` | int    | no       | Default: 3                                        |

Query: `?branchId=&courseId=&isActive=`

**Permission:** `fee-plan.manage`

---

### 3.13 Invoices

```
GET    /invoices
```

| Query Param     | Type   | Notes                                                               |
| --------------- | ------ | ------------------------------------------------------------------- |
| `branchId`      | number |                                                                     |
| `studentId`     | number |                                                                     |
| `status`        | string | `DRAFT`, `UNPAID`, `PARTIAL`, `PAID`, `OVERDUE`, `VOID`, `REFUNDED` |
| `from`          | date   | Issue date range                                                    |
| `to`            | date   |                                                                     |
| `dueBefore`     | date   | Find invoices due before this date                                  |
| `page`, `limit` | int    |                                                                     |

**Permission:** `invoice.read`

---

```
POST   /invoices
```

| Field          | Type   | Required | Notes                                                                 |
| -------------- | ------ | -------- | --------------------------------------------------------------------- |
| `branchId`     | number | yes      |                                                                       |
| `studentId`    | number | yes      |                                                                       |
| `enrollmentId` | number | no       |                                                                       |
| `feePlanId`    | number | no       | Auto-populates line items from the fee plan                           |
| `periodStart`  | date   | no       |                                                                       |
| `periodEnd`    | date   | no       |                                                                       |
| `dueDate`      | date   | yes      |                                                                       |
| `lineItems`    | array  | yes\*    | \*Required if no feePlanId. `[{ description, quantity, unitAmount }]` |
| `notes`        | string | no       |                                                                       |

**Clarification:** If `feePlanId` is provided and `lineItems` is empty, the system
generates a single line item from the fee plan amount. The `invoiceNumber` is auto-
generated as `{prefix}-{YYYY}-{sequence}` (prefix configurable in tenant settings).

**Status on creation:** `DRAFT`. Must be explicitly transitioned to `UNPAID` to become
"live" (triggers due-date tracking and reminder eligibility).

**Permission:** `invoice.create`

---

```
GET    /invoices/:id
```

Full detail: line items, applied discounts, payments, student info.

---

```
PATCH  /invoices/:id
```

| Field     | Type   | Notes                                                 |
| --------- | ------ | ----------------------------------------------------- |
| `dueDate` | date   | Only while `DRAFT`                                    |
| `notes`   | string |                                                       |
| `status`  | string | Allowed transitions: `DRAFT` → `UNPAID`, any → `VOID` |

**Clarification:** Voiding an invoice with payments on it does not auto-refund. The
admin must process refunds separately. Voiding sets status to `VOID` and is an
irreversible action (logged to `audit_logs`).

**Permission:** `invoice.update` / `invoice.void` (separate permission for voiding)

---

```
GET    /invoices/:id/line-items
POST   /invoices/:id/line-items
```

Add line items to a `DRAFT` invoice only.

| Field         | Type   | Required |
| ------------- | ------ | -------- |
| `description` | string | yes      |
| `quantity`    | number | yes      |
| `unitAmount`  | number | yes      |

**Side effect:** Recalculates invoice `subtotal`, `discountAmount`, and `total`.

---

```
GET    /invoices/:id/payments
```

Payments applied to this invoice.

---

```
POST   /invoices/:id/payments
```

Record a manual (usually cash) payment.

| Field    | Type     | Required | Notes                           |
| -------- | -------- | -------- | ------------------------------- |
| `amount` | number   | yes      |                                 |
| `method` | string   | yes      | `CASH`, `CARD`, `BANK_TRANSFER` |
| `paidAt` | datetime | no       | Default: now                    |
| `notes`  | string   | no       |                                 |

**Side effects:**

1. Creates `payments` row with status `SUCCEEDED`.
2. Increments `invoice.amountPaid`.
3. Recalculates invoice status: `PARTIAL` (if amountPaid < total) or `PAID`.
4. Emits `PaymentReceivedEvent` → receipt notification to parent.

**Clarification:** For online payments (Click/Payme/Uzum), do not use this endpoint.
Those are initiated by the Portal API (§5) and completed via webhooks (§1.2).

**Permission:** `payment.record`

---

```
POST   /invoices/:id/discounts
```

Apply a discount to an invoice.

| Field        | Type   | Required |
| ------------ | ------ | -------- |
| `discountId` | number | yes      |

**Validation:** Checks `discount.isActive`, `validFrom`/`validUntil`,
`maxUses`/`currentUses`. Returns 422 if the discount is exhausted or expired.

**Side effects:** Creates `invoice_discounts` row, increments
`discount.currentUses`, recalculates invoice totals.

**Permission:** `invoice.discount.apply`

---

### 3.14 Payments

```
GET    /payments
```

| Query Param     | Type   | Notes                                                     |
| --------------- | ------ | --------------------------------------------------------- |
| `branchId`      | number |                                                           |
| `studentId`     | number |                                                           |
| `invoiceId`     | number |                                                           |
| `method`        | string | `CASH`, `CLICK`, `PAYME`, `UZUM`, `CARD`, `BANK_TRANSFER` |
| `status`        | string | `PENDING`, `SUCCEEDED`, `FAILED`, `REFUNDED`              |
| `from`          | date   | `paidAt` range                                            |
| `to`            | date   |                                                           |
| `page`, `limit` | int    |                                                           |

---

```
GET    /payments/:id
```

Full detail: linked invoice, student, method, provider txn ID, timestamps.

**Permission:** `payment.read`

---

### 3.15 Discounts

```
GET    /discounts
POST   /discounts
PATCH  /discounts/:id
```

| Field (create) | Type   | Required | Notes                                          |
| -------------- | ------ | -------- | ---------------------------------------------- |
| `name`         | string | yes      |                                                |
| `type`         | string | yes      | `PERCENTAGE`, `FIXED_AMOUNT`                   |
| `value`        | number | yes      | Percentage (0–100) or fixed amount in currency |
| `applicableTo` | string | no       | Default: `invoice`                             |
| `code`         | string | no       | Promo code (unique per tenant if set)          |
| `maxUses`      | int    | no       | Null = unlimited                               |
| `validFrom`    | date   | no       |                                                |
| `validUntil`   | date   | no       |                                                |

Query: `?isActive=&search=`

**Permission:** `discount.manage`

---

### 3.16 Expenses

```
GET    /expenses
POST   /expenses
PATCH  /expenses/:id
DELETE /expenses/:id
```

| Field (create) | Type   | Required | Notes                                               |
| -------------- | ------ | -------- | --------------------------------------------------- |
| `branchId`     | number | yes      |                                                     |
| `category`     | string | yes      | `RENT`, `UTILITIES`, `MARKETING`, `SALARY`, `OTHER` |
| `amount`       | number | yes      |                                                     |
| `currency`     | string | no       | Default: `UZS`                                      |
| `expenseDate`  | date   | yes      |                                                     |
| `vendor`       | string | no       |                                                     |
| `description`  | string | no       |                                                     |
| `receiptUrl`   | string | no       | Upload via storage endpoint first                   |

Query: `?branchId=&category=&from=&to=`

**Permission:** `expense.create` / `expense.update` / `expense.delete`

---

### 3.17 Payroll

```
GET    /payrolls
```

| Query Param     | Type   | Notes                       |
| --------------- | ------ | --------------------------- |
| `branchId`      | number |                             |
| `staffId`       | number |                             |
| `status`        | string | `DRAFT`, `APPROVED`, `PAID` |
| `periodFrom`    | date   |                             |
| `periodTo`      | date   |                             |
| `page`, `limit` | int    |                             |

**Permission:** `payroll.read`

---

```
POST   /payrolls
```

| Field           | Type    | Required    | Notes                                                                     |
| --------------- | ------- | ----------- | ------------------------------------------------------------------------- |
| `branchId`      | number  | yes         |                                                                           |
| `staffId`       | number  | yes         | FK to staff.id                                                            |
| `periodStart`   | date    | yes         |                                                                           |
| `periodEnd`     | date    | yes         |                                                                           |
| `autoCalculate` | boolean | no          | Default: true. If true, the system calculates from sessions taught × rate |
| `grossAmount`   | number  | conditional | Required if `autoCalculate` is false                                      |
| `deductions`    | number  | no          | Default: 0                                                                |
| `breakdown`     | object  | no          | e.g. `{ "hoursTaught": 40, "rate": 50000, "bonuses": 100000 }`            |

**Clarification:** `autoCalculate: true` counts sessions where the staff member was
the teacher (or substitute) within the period, multiplies by
`staff.baseSalary / expected monthly hours`, and adds any bonuses from the breakdown.

**Permission:** `payroll.create`

---

```
GET    /payrolls/:id
PATCH  /payrolls/:id
```

PATCH: `grossAmount`, `deductions`, `breakdown` (only while `DRAFT`).

---

```
POST   /payrolls/:id/approve
```

Transitions `DRAFT` → `APPROVED`. Requires a different user than the one who created
it (separation of duties, if configured).

**Permission:** `payroll.approve`

---

```
POST   /payrolls/:id/mark-paid
```

Transitions `APPROVED` → `PAID`. Sets `paidAt`.

**Permission:** `payroll.pay`

---

### 3.18 Communication

```
GET    /notification-templates
POST   /notification-templates
PATCH  /notification-templates/:id
```

| Field (create) | Type   | Required | Notes                                                                                                                      |
| -------------- | ------ | -------- | -------------------------------------------------------------------------------------------------------------------------- |
| `code`         | string | yes      | `INVOICE_DUE`, `ABSENCE_ALERT`, `WELCOME`, `PAYMENT_RECEIVED`, `SCHEDULE_CHANGE`, `RESULTS_PUBLISHED`                      |
| `channel`      | string | yes      | `SMS`, `TELEGRAM`, `EMAIL`, `PUSH`                                                                                         |
| `locale`       | string | no       | Default: `uz`. `uz`, `ru`, `en`                                                                                            |
| `subject`      | string | no       | Email subject only                                                                                                         |
| `body`         | string | yes      | Supports variables: `{{studentName}}`, `{{parentName}}`, `{{dueDate}}`, `{{amount}}`, `{{groupName}}`, `{{invoiceNumber}}` |

**Clarification:** Template uniqueness is per `(tenantId, code, channel, locale)`. You
can have the same INVOICE_DUE template in SMS/uz, SMS/ru, and TELEGRAM/uz.

**Permission:** `notification-template.manage`

---

```
GET    /notifications
```

| Query Param       | Type   | Notes                                   |
| ----------------- | ------ | --------------------------------------- |
| `status`          | string | `QUEUED`, `SENT`, `DELIVERED`, `FAILED` |
| `channel`         | string |                                         |
| `recipientUserId` | number |                                         |
| `from`            | date   |                                         |
| `to`              | date   |                                         |
| `page`, `limit`   | int    |                                         |

---

```
POST   /notifications
```

Manual send / broadcast.

| Field               | Type     | Required    | Notes                                |
| ------------------- | -------- | ----------- | ------------------------------------ |
| `channel`           | string   | yes         |                                      |
| `templateId`        | number   | no          | Use template, or provide raw `body`  |
| `body`              | string   | conditional | Required if no templateId            |
| `recipientUserIds`  | number[] | conditional | Specific users                       |
| `recipientGroupId`  | number   | conditional | All students in a group              |
| `recipientBranchId` | number   | conditional | All students in a branch             |
| `variables`         | object   | no          | `{ "groupName": "IELTS Morning A" }` |
| `scheduledAt`       | datetime | no          | Schedule for later delivery          |

**Clarification:** Exactly one recipient scope must be provided (userIds OR groupId
OR branchId). The system resolves individual recipients, creates one `notifications`
row per recipient, and queues them for dispatch.

**Permission:** `notification.send`

---

```
GET    /payment-reminder-rules
POST   /payment-reminder-rules
PATCH  /payment-reminder-rules/:id
```

| Field (create) | Type   | Required | Notes                                                        |
| -------------- | ------ | -------- | ------------------------------------------------------------ |
| `branchId`     | number | no       | Null = applies tenant-wide                                   |
| `name`         | string | yes      | e.g. "3 days before due"                                     |
| `daysOffset`   | int    | yes      | Negative = before due, 0 = on due date, positive = after due |
| `channel`      | string | yes      | `SMS`, `TELEGRAM`                                            |
| `templateId`   | number | no       |                                                              |

**Clarification:** A background worker runs daily (configurable), scans all `UNPAID`
and `PARTIAL` invoices, and for each matching `(dueDate + daysOffset = today)` pair,
enqueues a notification. Each (invoice, rule) combination is sent at most once
(tracked internally to avoid duplicate reminders).

**Permission:** `reminder-rule.manage`

---

### 3.19 Learning Materials

```
POST   /materials
```

| Field          | Type   | Required | Notes                                         |
| -------------- | ------ | -------- | --------------------------------------------- |
| `branchId`     | number | yes      |                                               |
| `groupId`      | number | no       |                                               |
| `courseId`     | number | no       |                                               |
| `title`        | string | yes      |                                               |
| `description`  | string | no       |                                               |
| `fileUrl`      | string | yes      | From a prior file-upload call                 |
| `materialType` | string | yes      | `PDF`, `VIDEO`, `HOMEWORK`, `LINK`            |
| `visibility`   | string | no       | Default: `GROUP`. `GROUP`, `BRANCH`, `TENANT` |

**Permission:** `material.create`

---

```
GET    /materials/:id
DELETE /materials/:id
```

**Permission:** `material.read` / `material.delete`

---

### 3.20 Audit Logs

```
GET    /audit-logs
```

| Query Param     | Type   | Notes                                    |
| --------------- | ------ | ---------------------------------------- |
| `userId`        | number | Filter by actor                          |
| `action`        | string | e.g. `INVOICE_VOIDED`, `STUDENT_DELETED` |
| `entityType`    | string | e.g. `Invoice`, `Student`                |
| `entityId`      | number |                                          |
| `from`          | date   |                                          |
| `to`            | date   |                                          |
| `page`, `limit` | int    |                                          |

**Response includes:** actor name, action, entity type/id, before/after diff, IP
address, timestamp.

**Permission:** `audit.read`

---

### 3.21 Dashboards

```
GET    /dashboard/financial
```

| Query Param | Type   | Notes                           |
| ----------- | ------ | ------------------------------- |
| `branchId`  | number | Null = across all branches      |
| `from`      | date   | Default: start of current month |
| `to`        | date   | Default: today                  |

**Response:**

```json
{
  "totalRevenue": 45000000,
  "totalExpenses": 12000000,
  "netIncome": 33000000,
  "outstandingReceivables": 8500000,
  "overdueAmount": 3200000,
  "overdueCount": 12,
  "paymentMethodBreakdown": { "CASH": 20000000, "CLICK": 15000000, "PAYME": 10000000 },
  "monthlyTrend": [{ "month": "2025-01", "revenue": 14000000, "expenses": 4000000 }],
  "currency": "UZS"
}
```

---

```
GET    /dashboard/academic
```

| Query Param | Type   | Notes |
| ----------- | ------ | ----- |
| `branchId`  | number |       |
| `groupId`   | number |       |

**Response:** Active students count, active groups count, average assessment scores,
pass rate, score distribution histogram.

---

```
GET    /dashboard/attendance
```

| Query Param | Type   | Notes |
| ----------- | ------ | ----- |
| `branchId`  | number |       |
| `from`      | date   |       |
| `to`        | date   |       |

**Response:** Overall attendance rate, rate by group, chronic absentees (students with
<75% attendance), daily trend.

---

```
GET    /dashboard/crm
```

**Response:** Lead count by status (funnel), conversion rate, average time-to-enroll,
leads by source, leads this month vs last month.

**Permission:** `dashboard.read` (all four dashboards share this permission)

---

### 3.22 Current User (`/me`)

```
GET    /me
```

Returns the authenticated staff member's profile, role names and **resolved
permission codes** — what the back-office web app needs on load to gate its UI by
permission (not just by role).

**Auth:** The standard Manage gate (OWNER/ADMIN/MANAGER). No specific permission is
required — any staff principal that clears the role gate may read their own profile.

**Response 200:**

```json
{
  "id": 1,
  "firstName": "...",
  "lastName": "...",
  "email": "...",
  "phone": "+998...",
  "avatarUrl": "...",
  "roles": ["ADMIN"],
  "branchScope": [1],
  "permissions": ["invoice.void", "student.create", "student.read"]
}
```

| Field         | Notes                                                                                                                                                                                         |
| ------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `roles`       | Role names from the access token (the 15m authorization snapshot the `TenantRoleGuard` enforces).                                                                                             |
| `branchScope` | Branch ids the user is scoped to, or `null` for all branches.                                                                                                                                 |
| `permissions` | Effective permission codes, deduped and sorted. Resolved **fresh** from the user's roles — the same source the `RbacGuard` enforces — so UI gating stays aligned with what the server allows. |

**Clarification:** `permissions` is computed server-side by walking
`user_role_assignments → roles → role_permissions → permissions`; it is intentionally
**not** embedded in the JWT, so a role/permission change is reflected on the next call
without re-issuing tokens. The student/parent portal has its own profile endpoint
(§5.1) for the self-service apps.

---

## 4. Teacher API (`/api/v1/teach`)

**Auth:** `TenantRoleGuard(['TEACHER'])`. All data is auto-filtered to groups where
the authenticated user is the `defaultTeacherId` or the session `teacherId`
(substitute). A teacher cannot see groups they don't teach.

### 4.1 My Schedule

```
GET    /sessions
```

| Query Param | Type   | Required | Notes             |
| ----------- | ------ | -------- | ----------------- |
| `from`      | date   | yes      |                   |
| `to`        | date   | yes      | Max span: 90 days |
| `status`    | string | no       |                   |

**Clarification:** Returns sessions where the teacher is either the group's default
teacher or the session's substitute teacher. Includes group name, course name, room,
and student count.

---

```
GET    /sessions/:id
```

Session detail + enrolled student roster.

---

### 4.2 My Groups

```
GET    /groups
```

Groups assigned to this teacher. Includes course name, student count, schedule rule,
status.

---

```
GET    /groups/:id
```

Group detail with full roster (student names, codes, contact info).

---

```
GET    /groups/:id/students
```

Enriched roster: student name, phone, email, enrollment date, attendance rate for this
group.

---

### 4.3 Attendance (write)

```
GET    /sessions/:id/attendances
```

Current attendance state for this session. Returns the student roster with any
already-marked statuses.

---

```
POST   /sessions/:id/attendances
```

**Batch submit** attendance for an entire class.

| Field     | Type  | Required | Notes                                                      |
| --------- | ----- | -------- | ---------------------------------------------------------- |
| `records` | array | yes      | `[{ "studentId": 1, "status": "PRESENT", "note": "..." }]` |

**Validation:**

- Session must be `SCHEDULED` or `COMPLETED` (not `CANCELLED`).
- All `studentId` values must be enrolled in the session's group.
- Duplicate (session, student) pairs are rejected with 409.

**Side effects:**

- Sets `markedByStaffId` to the authenticated teacher and `markedAt` to now.
- Emits `AttendanceMarkedEvent` for each `ABSENT` student → communication module
  sends absence alert to primary guardian.

---

```
PATCH  /sessions/:id/attendances
```

**Batch update** — modify previously submitted records.

| Field     | Type  | Required |
| --------- | ----- | -------- |
| `records` | array | yes      |

Each record: `{ "studentId": 1, "status": "LATE", "note": "arrived 15 min late" }`.

**Clarification:** Updates existing rows only (matched by session + student). Does not
create new records. Use POST for initial submission, PATCH for corrections.

---

### 4.4 Assessments (full CRUD for my groups)

```
GET    /assessments
```

Assessments across all my groups. Supports `?groupId=&type=&from=&to=`.

---

```
POST   /assessments
```

| Field            | Type   | Required | Notes                                          |
| ---------------- | ------ | -------- | ---------------------------------------------- |
| `groupId`        | number | yes      | Must be a group I teach                        |
| `gradingScaleId` | number | no       |                                                |
| `title`          | string | yes      |                                                |
| `type`           | string | yes      | `QUIZ`, `MIDTERM`, `FINAL`, `MOCK`, `HOMEWORK` |
| `examDate`       | date   | no       |                                                |
| `maxScore`       | number | no       | Default: 100                                   |
| `weight`         | number | no       | Default: 1.0                                   |

---

```
GET    /assessments/:id
PATCH  /assessments/:id
```

PATCH: `title`, `type`, `examDate`, `maxScore`, `weight`, `gradingScaleId`.

---

```
GET    /assessments/:id/results
```

Results for this assessment with student names.

---

```
POST   /assessments/:id/results
```

**Batch submit** grades.

| Field     | Type  | Required |
| --------- | ----- | -------- |
| `results` | array | yes      |

Each result: `{ "studentId": 1, "score": 87.5, "feedback": "Good improvement" }`.

**Side effects:**

- The `GradeCalculatorService` derives `gradeLabel` from the assessment's grading
  scale (or the tenant's default scale).
- `percentileRank` is calculated relative to all results in this assessment.
- Sets `gradedByStaffId` and `gradedAt`.

---

```
PATCH  /assessments/:id/results
```

Batch update grades. Same format as POST, updates matched by (assessment, student).

---

```
POST   /assessments/:id/publish
```

Sets `isPublished = true`. Once published, results become visible to students and
parents via the Portal API.

**Side effects:** Emits `ResultsPublishedEvent` → notification to students/parents.

---

### 4.5 Learning Materials

```
GET    /materials
```

Materials for my groups. Supports `?groupId=`.

---

```
POST   /materials
```

Same fields as §3.19 but `branchId` is auto-set from the group's branch, and the
teacher can only upload to groups they teach.

---

```
DELETE /materials/:id
```

Only materials the teacher uploaded themselves.

---

### 4.6 Student Profiles (read-only)

```
GET    /students/:id
```

**Limited fields:** name, phone, email, avatar, student code, date of birth, gender,
enrolled-at, status, emergency contact.

**Not included:** address, notes, financial information, guardian details.

**Clarification:** The teacher can only view students enrolled in their groups.

---

```
GET    /students/:id/attendances
```

Attendance history for this student across the teacher's groups. Supports `?from=&to=`.

---

```
GET    /students/:id/results
```

Assessment results for this student in the teacher's groups.

---

### 4.7 Grading Scales (read-only)

```
GET    /grading-scales
```

Full catalog of tenant grading scales. Teachers need this to know what scale to
assign when creating an assessment.

---

## 5. Student & Parent Portal API (`/api/v1/portal`)

**Auth:** `TenantRoleGuard(['STUDENT', 'PARENT'])`.

**Scoping rules:**

- **Student:** Sees only their own data (enrollments, attendance, grades, invoices).
- **Parent:** Sees data for all children linked via `student_guardians`. Most list
  endpoints accept an optional `?studentId=` to filter to a specific child; without it,
  returns data for all children.

### 5.1 Profile

```
GET    /me
```

Returns the current user's profile.

**Response (student):**

```json
{
  "id": 1,
  "firstName": "...",
  "lastName": "...",
  "phone": "+998...",
  "email": "...",
  "avatar": "...",
  "preferredLanguage": "uz",
  "role": "STUDENT",
  "student": {
    "id": 1,
    "studentCode": "STU-2025-042",
    "branchName": "Yunusobod",
    "status": "ACTIVE",
    "enrolledAt": "2025-01-15"
  }
}
```

**Response (parent):** Same user fields, plus `children: [{ id, firstName, lastName, studentCode, branchName }]`.

---

```
PATCH  /me
```

| Field               | Type   | Notes                    |
| ------------------- | ------ | ------------------------ |
| `email`             | string |                          |
| `preferredLanguage` | string | `uz`, `ru`, `en`         |
| `avatarUrl`         | string | From a prior file upload |

**Clarification:** Phone number cannot be changed via this endpoint (it's the login
identifier). Phone changes require admin action.

---

### 5.2 My Children (parent only)

```
GET    /children
```

Returns the parent's linked students with basic profile info and status.

**Response:**

```json
[
  {
    "studentId": 1,
    "firstName": "...",
    "lastName": "...",
    "studentCode": "STU-2025-042",
    "branchName": "Yunusobod",
    "status": "ACTIVE",
    "relation": "father"
  }
]
```

---

### 5.3 Schedule

```
GET    /schedule
```

| Query Param | Type   | Required | Notes                       |
| ----------- | ------ | -------- | --------------------------- |
| `from`      | date   | yes      |                             |
| `to`        | date   | yes      | Max span: 30 days           |
| `studentId` | number | no       | Parent: filter to one child |

**Response:** Array of sessions the student is enrolled in. Each includes: date,
start/end time, course name, group name, teacher name, room name, topic, status.

**Scoping:** Student sees their own sessions. Parent sees all children's sessions
(merged, deduplicated).

---

### 5.4 Attendance

```
GET    /attendance
```

| Query Param     | Type   | Notes                              |
| --------------- | ------ | ---------------------------------- |
| `studentId`     | number | Parent: required to select a child |
| `groupId`       | number | Filter by group                    |
| `from`          | date   |                                    |
| `to`            | date   |                                    |
| `page`, `limit` | int    |                                    |

**Response:** Attendance records with session date, group/course name, status, note.

---

### 5.5 Grades & Results

```
GET    /results
```

| Query Param     | Type   | Notes |
| --------------- | ------ | ----- |
| `studentId`     | number |       |
| `groupId`       | number |       |
| `page`, `limit` | int    |       |

**Clarification:** Only returns results from **published** assessments
(`assessments.isPublished = true`). Unpublished results are invisible to students
and parents.

**Response:** assessment title, type, exam date, score, max score, grade label,
percentile rank, teacher feedback, course/group name.

---

```
GET    /results/:id
```

Single result detail.

---

### 5.6 Report Cards

```
GET    /report-cards
```

| Query Param     | Type   | Notes |
| --------------- | ------ | ----- |
| `studentId`     | number |       |
| `page`, `limit` | int    |       |

**Clarification:** Only returns `PUBLISHED` report cards.

---

```
GET    /report-cards/:id
```

Full report card with line items.

---

```
GET    /report-cards/:id/download
```

Returns the rendered PDF file. Content-Type: `application/pdf`.

**Clarification:** Returns 404 if the PDF hasn't been generated yet (`fileUrl` is
null). The admin must generate it first via the Manage API.

---

### 5.7 Learning Materials

```
GET    /materials
```

| Query Param | Type   | Notes |
| ----------- | ------ | ----- |
| `studentId` | number |       |
| `groupId`   | number |       |

**Scoping:** Returns materials for groups the student is enrolled in, filtered by
visibility (`GROUP` → only that group's enrolled students, `BRANCH` → any student in
the branch, `TENANT` → any student).

---

```
GET    /materials/:id
```

Material detail with download URL.

---

### 5.8 Invoices

```
GET    /invoices
```

| Query Param     | Type   | Notes                  |
| --------------- | ------ | ---------------------- |
| `studentId`     | number | Parent: select a child |
| `status`        | string |                        |
| `page`, `limit` | int    |                        |

**Clarification:** `DRAFT` invoices are **not** visible to students/parents. Only
`UNPAID`, `PARTIAL`, `PAID`, `OVERDUE`, `REFUNDED` are shown.

**Response includes:** invoice number, issue date, due date, total, amount paid,
balance (total − amountPaid), status, line items summary.

---

```
GET    /invoices/:id
```

Full invoice detail with line items and applied discounts.

---

```
POST   /invoices/:id/pay
```

Initiates an online payment.

| Field       | Type   | Required | Notes                                                |
| ----------- | ------ | -------- | ---------------------------------------------------- |
| `method`    | string | yes      | `CLICK`, `PAYME`, `UZUM`                             |
| `amount`    | number | no       | Default: remaining balance. Partial payments allowed |
| `returnUrl` | string | no       | Where to redirect after payment                      |

**Response:**

```json
{
  "paymentId": 1,
  "redirectUrl": "https://my.click.uz/...",
  "status": "PENDING"
}
```

**Flow:**

1. Creates a `payments` row with status `PENDING` and a generated `idempotencyKey`.
2. Calls the payment gateway adapter to create a checkout session.
3. Returns the gateway's redirect URL.
4. User completes payment on the gateway's page.
5. Gateway sends a webhook to `/api/v1/public/webhooks/{provider}`.
6. Webhook handler updates payment status and invoice balance.

**Clarification:** The invoice must be `UNPAID`, `PARTIAL`, or `OVERDUE`. Attempting
to pay a `PAID`, `VOID`, or `DRAFT` invoice returns 422.

---

### 5.9 Payment History

```
GET    /payments
```

| Query Param     | Type   | Notes |
| --------------- | ------ | ----- |
| `studentId`     | number |       |
| `page`, `limit` | int    |       |

**Response:** Amount, method, status, paid date, linked invoice number.

---

### 5.10 Notifications

```
GET    /notifications
```

| Query Param     | Type | Notes |
| --------------- | ---- | ----- |
| `page`, `limit` | int  |       |

**Response:** The user's received notifications (newest first). Includes channel,
rendered body, sent timestamp, status.

**Clarification:** This endpoint returns notifications from the database outbox. For
Telegram notifications, the user also receives them in real-time via the bot; this
endpoint serves as an in-app archive.

---

## Appendix A: Enums & Status Values

These are the allowed values for status and type fields across the system. Use these
exact strings in request bodies and query parameters.

### Entity Statuses

| Entity        | Field   | Values                                                              |
| ------------- | ------- | ------------------------------------------------------------------- |
| Tenant        | status  | `ACTIVE`, `SUSPENDED`, `PENDING`, `CANCELLED`                       |
| Subscription  | status  | `TRIALING`, `ACTIVE`, `PAST_DUE`, `CANCELLED`                       |
| Tenant User   | status  | `INVITED`, `ACTIVE`, `SUSPENDED`                                    |
| Student       | status  | `ACTIVE`, `INACTIVE`, `GRADUATED`, `SUSPENDED`                      |
| Staff         | status  | `ACTIVE`, `ON_LEAVE`, `TERMINATED`                                  |
| Lead          | status  | `NEW`, `CONTACTED`, `TRIAL_BOOKED`, `ENROLLED`, `LOST`              |
| Group         | status  | `PLANNED`, `ACTIVE`, `COMPLETED`, `CANCELLED`                       |
| Session       | status  | `SCHEDULED`, `COMPLETED`, `CANCELLED`                               |
| Enrollment    | status  | `ACTIVE`, `DROPPED`, `COMPLETED`, `TRANSFERRED`                     |
| Attendance    | status  | `PRESENT`, `ABSENT`, `LATE`, `EXCUSED`                              |
| Assessment    | type    | `QUIZ`, `MIDTERM`, `FINAL`, `MOCK`, `HOMEWORK`                      |
| Grading Scale | type    | `NUMERIC`, `PERCENTAGE`, `LETTER`, `BAND`                           |
| Report Card   | status  | `DRAFT`, `PUBLISHED`                                                |
| Invoice       | status  | `DRAFT`, `UNPAID`, `PARTIAL`, `PAID`, `OVERDUE`, `VOID`, `REFUNDED` |
| Payment       | status  | `PENDING`, `SUCCEEDED`, `FAILED`, `REFUNDED`                        |
| Payment       | method  | `CASH`, `CLICK`, `PAYME`, `UZUM`, `CARD`, `BANK_TRANSFER`           |
| Discount      | type    | `PERCENTAGE`, `FIXED_AMOUNT`                                        |
| Payroll       | status  | `DRAFT`, `APPROVED`, `PAID`                                         |
| Notification  | status  | `QUEUED`, `SENT`, `DELIVERED`, `FAILED`                             |
| Notification  | channel | `SMS`, `TELEGRAM`, `EMAIL`, `PUSH`                                  |

### Other Enums

| Field                  | Values                                                             |
| ---------------------- | ------------------------------------------------------------------ |
| Staff employment type  | `FULL_TIME`, `PART_TIME`, `CONTRACTOR`                             |
| Gender                 | `M`, `F`, `O`                                                      |
| Lead source            | `INSTAGRAM`, `TELEGRAM`, `REFERRAL`, `WALK_IN`, `WEBSITE`, `OTHER` |
| Fee plan billing cycle | `MONTHLY`, `QUARTERLY`, `ONE_TIME`, `PER_SESSION`                  |
| Material type          | `PDF`, `VIDEO`, `HOMEWORK`, `LINK`                                 |
| Material visibility    | `GROUP`, `BRANCH`, `TENANT`                                        |
| Room type              | `classroom`, `lab`, `online`                                       |
| Lead activity type     | `CALL`, `MESSAGE`, `TRIAL`, `NOTE`                                 |
| Preferred language     | `uz`, `ru`, `en`                                                   |
| Guardian relation      | `mother`, `father`, `guardian`                                     |

---

## Appendix B: Standard Response Envelope

All responses are wrapped in a standard envelope:

**Success:**

```json
{
  "success": true,
  "data": { ... },
  "meta": {
    "timestamp": "2025-03-15T10:30:00+05:00"
  }
}
```

**Paginated:**

```json
{
  "success": true,
  "data": [ ... ],
  "meta": {
    "page": 1,
    "limit": 20,
    "total": 145,
    "totalPages": 8,
    "timestamp": "2025-03-15T10:30:00+05:00"
  }
}
```

**Error:**

```json
{
  "success": false,
  "error": {
    "code": "INVOICE_ALREADY_VOID",
    "message": "This invoice has already been voided and cannot be modified.",
    "details": {}
  },
  "meta": {
    "timestamp": "2025-03-15T10:30:00+05:00"
  }
}
```

### HTTP Status Codes Used

| Code | When                                                                   |
| ---- | ---------------------------------------------------------------------- |
| 200  | Successful read or update                                              |
| 201  | Successful create                                                      |
| 202  | Accepted (async job queued, e.g. report card generation)               |
| 204  | Successful delete (no body)                                            |
| 400  | Invalid input (malformed ID, missing required field)                   |
| 401  | Authentication failed or missing                                       |
| 403  | Authenticated but lacking permission / wrong branch / suspended tenant |
| 404  | Resource not found (or soft-deleted) within the tenant                 |
| 409  | Conflict (duplicate enrollment, group at capacity, room double-booked) |
| 422  | Business rule violation (expired discount, paying a void invoice)      |
| 429  | Rate limited                                                           |
| 500  | Internal server error                                                  |

---

## Appendix C: Pagination

All list endpoints support cursor-less offset pagination:

| Param   | Type | Default | Max |
| ------- | ---- | ------- | --- |
| `page`  | int  | 1       |     |
| `limit` | int  | 20      | 100 |

Sort defaults to `createdAt DESC` unless the endpoint specifies otherwise (e.g.
sessions sort by `sessionDate ASC`, audit logs by `createdAt DESC`).

Optional sort params (where supported): `?sort=createdAt&order=asc`.
